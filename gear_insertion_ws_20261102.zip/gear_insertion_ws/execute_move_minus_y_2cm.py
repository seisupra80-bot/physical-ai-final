import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from sensor_msgs.msg import JointState
from geometry_msgs.msg import Pose
from moveit_msgs.srv import GetCartesianPath
from moveit_msgs.msg import RobotState
from control_msgs.action import FollowJointTrajectory


NAMES = [
    'panda_joint1', 'panda_joint2', 'panda_joint3',
    'panda_joint4', 'panda_joint5', 'panda_joint6',
    'panda_joint7',
    'panda_finger_joint1', 'panda_finger_joint2',
]

ARM_NAMES = NAMES[:7]


class MoveMinusY(Node):
    def __init__(self):
        super().__init__('execute_minus_y_2cm')

        self.state = None
        self.create_subscription(
            JointState, '/merged_joint_states',
            self.joint_callback, 10
        )

        self.cartesian = self.create_client(
            GetCartesianPath, '/compute_cartesian_path'
        )

        self.action = ActionClient(
            self,
            FollowJointTrajectory,
            '/panda_arm_controller/follow_joint_trajectory'
        )

    def joint_callback(self, msg):
        self.state = dict(zip(msg.name, msg.position))

    def run(self):
        deadline = time.monotonic() + 15.0
        while self.state is None and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.2)

        if self.state is None or not all(n in self.state for n in NAMES):
            self.get_logger().error('Joint state unavailable. Aborting.')
            return

        current = [self.state[n] for n in NAMES]

        if not self.cartesian.wait_for_service(timeout_sec=10):
            self.get_logger().error('Cartesian service unavailable.')
            return

        if not self.action.wait_for_server(timeout_sec=10):
            self.get_logger().error('Trajectory action unavailable.')
            return

        req = GetCartesianPath.Request()
        req.header.frame_id = 'world'

        req.start_state = RobotState()
        req.start_state.joint_state.name = NAMES
        req.start_state.joint_state.position = current

        req.group_name = 'panda_arm'
        req.link_name = 'panda_hand'

        pose = Pose()
        pose.position.x = 0.550
        pose.position.y = -0.472
        pose.position.z = 0.966

        pose.orientation.x = 0.575
        pose.orientation.y = 0.575
        pose.orientation.z = 0.411
        pose.orientation.w = -0.411

        req.waypoints.append(pose)
        req.max_step = 0.005
        req.jump_threshold = 0.0
        req.avoid_collisions = True
        req.max_velocity_scaling_factor = 0.1
        req.max_acceleration_scaling_factor = 0.1

        self.get_logger().info(
            'Planning horizontal -Y 2cm path from latest joint state.'
        )

        future = self.cartesian.call_async(req)
        rclpy.spin_until_future_complete(
            self, future, timeout_sec=60
        )

        if not future.done() or future.result() is None:
            self.get_logger().error('Planning timeout. No movement.')
            return

        res = future.result()
        trajectory = res.solution.joint_trajectory

        self.get_logger().info(f'Error code: {res.error_code.val}')
        self.get_logger().info(f'Cartesian fraction: {res.fraction:.4f}')
        self.get_logger().info(
            f'Trajectory points: {len(trajectory.points)}'
        )

        if res.error_code.val != 1 or res.fraction < 0.999:
            self.get_logger().error('Plan incomplete. No movement.')
            return

        if not trajectory.points:
            self.get_logger().error('Empty trajectory. No movement.')
            return

        current_arm = [self.state[n] for n in ARM_NAMES]
        first = trajectory.points[0].positions

        if len(first) != len(trajectory.joint_names):
            self.get_logger().error('Unexpected trajectory. No movement.')
            return

        start_arm = [
            first[trajectory.joint_names.index(n)] for n in ARM_NAMES
        ]

        difference = max(
            abs(a - b) for a, b in zip(current_arm, start_arm)
        )

        self.get_logger().info(
            f'Maximum start-state difference: {difference:.6f} rad'
        )

        if difference > 0.02:
            self.get_logger().error(
                'Start state mismatch. No movement.'
            )
            return

        self.get_logger().info(
            'Plan passed. Sending -Y 2cm trajectory now.'
        )

        goal = FollowJointTrajectory.Goal()
        goal.trajectory = trajectory
        goal.goal_time_tolerance.sec = 10

        send = self.action.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, send)

        handle = send.result()
        if handle is None or not handle.accepted:
            self.get_logger().error('Trajectory rejected.')
            return

        self.get_logger().info('Trajectory accepted. Panda is moving.')

        result_future = handle.get_result_async()
        rclpy.spin_until_future_complete(
            self, result_future, timeout_sec=60
        )

        if not result_future.done():
            self.get_logger().error('Execution timeout. Check Gazebo.')
            return

        result = result_future.result().result
        self.get_logger().info(
            f'Controller error_code: {result.error_code}'
        )
        self.get_logger().info(
            f'Controller message: {result.error_string}'
        )

        if result.error_code == 0:
            self.get_logger().info('MINUS Y 2CM MOTION COMPLETED')
        else:
            self.get_logger().error('Motion did not complete successfully.')


def main():
    rclpy.init()
    node = MoveMinusY()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
