import sys
import time
import subprocess

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from sensor_msgs.msg import JointState
from control_msgs.action import FollowJointTrajectory

from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import (
    MotionPlanRequest,
    Constraints,
    JointConstraint,
)


ARM_JOINTS = [
    'panda_joint1', 'panda_joint2', 'panda_joint3',
    'panda_joint4', 'panda_joint5', 'panda_joint6',
    'panda_joint7'
]

READY = [
    0.0, -0.785, 0.0, -2.356,
    0.0, 1.571, 0.785
]

GRASP = [
    -0.0000786,
    -0.5258634,
     0.0000402,
    -1.5513850,
     0.0000625,
     2.2663536,
     0.7853629
]


class GraspVideo(Node):

    def __init__(self):
        super().__init__('grasp_video_execution')

        self.latest_state = None

        self.create_subscription(
            JointState,
            '/merged_joint_states',
            self.state_callback,
            10
        )

        self.plan_client = self.create_client(
            GetMotionPlan,
            '/plan_kinematic_path'
        )

        self.arm_client = ActionClient(
            self,
            FollowJointTrajectory,
            '/panda_arm_controller/follow_joint_trajectory'
        )

    def state_callback(self, msg):
        self.latest_state = msg

    def get_state(self):
        for _ in range(50):
            rclpy.spin_once(self, timeout_sec=0.1)

            if self.latest_state is not None:
                state = dict(zip(
                    self.latest_state.name,
                    self.latest_state.position
                ))

                if all(j in state for j in ARM_JOINTS):
                    return state

        return None

    def plan(self, start, target):
        request = GetMotionPlan.Request()
        plan = MotionPlanRequest()

        plan.group_name = 'panda_arm'
        plan.pipeline_id = 'ompl'
        plan.planner_id = 'RRTConnect'
        plan.num_planning_attempts = 1
        plan.allowed_planning_time = 2.0
        plan.max_velocity_scaling_factor = 0.1
        plan.max_acceleration_scaling_factor = 0.1

        plan.start_state.joint_state.name = ARM_JOINTS
        plan.start_state.joint_state.position = [
            start[j] for j in ARM_JOINTS
        ]
        plan.start_state.is_diff = False

        constraints = Constraints()

        for name, position in zip(ARM_JOINTS, target):
            jc = JointConstraint()
            jc.joint_name = name
            jc.position = position
            jc.tolerance_above = 0.01
            jc.tolerance_below = 0.01
            jc.weight = 1.0
            constraints.joint_constraints.append(jc)

        plan.goal_constraints.append(constraints)
        request.motion_plan_request = plan

        future = self.plan_client.call_async(request)

        while rclpy.ok() and not future.done():
            rclpy.spin_once(self, timeout_sec=0.1)

        if not future.done() or future.result() is None:
            return None

        response = future.result().motion_plan_response

        self.get_logger().info(
            f'MoveIt error code: {response.error_code.val}'
        )
        self.get_logger().info(
            f'MoveIt error message: {response.error_code}'
        )

        if response.error_code.val != 1:
            return None

        return response.trajectory.joint_trajectory

    def execute(self, trajectory):
        goal = FollowJointTrajectory.Goal()
        goal.trajectory = trajectory

        future = self.arm_client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, future)

        handle = future.result()

        if handle is None or not handle.accepted:
            self.get_logger().error('Arm trajectory rejected.')
            return False

        result_future = handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)

        result = result_future.result()

        return (
            result is not None
            and result.result.error_code == 0
        )

    def close_fingers(self):
        commands = [
            ['/panda_left_finger_cmd', 'data: 0.015'],
            ['/panda_right_finger_cmd', 'data: 0.015'],
        ]

        for topic, message in commands:
            result = subprocess.run(
                [
                    'gz', 'topic',
                    '-t', topic,
                    '-m', 'gz.msgs.Double',
                    '-p', message
                ],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode != 0:
                self.get_logger().error(
                    f'Gazebo command failed: {topic}\n{result.stderr}'
                )
                return False

        return True


def main():
    if '--execute' not in sys.argv:
        print('実行する場合:')
        print('python3 execute_grasp_video.py --execute')
        print('安全のため --execute が必要です。')
        return

    rclpy.init()
    node = GraspVideo()

    try:
        node.get_logger().info('Checking joint states...')

        state = node.get_state()

        if state is None:
            node.get_logger().error('Joint states unavailable. STOP.')
            return

        if not node.plan_client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error('MoveIt service unavailable. STOP.')
            return

        if not node.arm_client.wait_for_server(timeout_sec=5.0):
            node.get_logger().error('Arm action server unavailable. STOP.')
            return

        node.get_logger().info('Control interfaces ready.')

        # 1. 現在姿勢からReady姿勢へ
        node.get_logger().info('STEP A: Planning current -> READY')

        trajectory = node.plan(state, READY)

        if trajectory is None:
            node.get_logger().error('READY planning failed. STOP.')
            return

        if '--plan-only' in sys.argv:
            node.get_logger().info(
                f'PLAN ONLY: READY trajectory generated '
                f'({len(trajectory.points)} points). No motion executed.'
            )
            return

        node.get_logger().info('Executing READY motion.')

        if not node.execute(trajectory):
            node.get_logger().error('READY motion failed. STOP.')
            return

        time.sleep(0.5)

        # 2. Ready姿勢から把持姿勢へ
        state = node.get_state()

        if state is None:
            node.get_logger().error('Joint states unavailable. STOP.')
            return

        node.get_logger().info('STEP B: Planning READY -> GRASP')

        trajectory = node.plan(state, GRASP)

        if trajectory is None:
            node.get_logger().error('GRASP planning failed. STOP.')
            return

        node.get_logger().info('Executing GRASP approach.')

        if not node.execute(trajectory):
            node.get_logger().error('GRASP approach failed. STOP.')
            return

        time.sleep(0.5)

        # 3. 左右の指を閉じる
        node.get_logger().info('STEP C: Closing fingers.')

        if not node.close_fingers():
            node.get_logger().error('Finger command failed. STOP.')
            return

        time.sleep(2.0)

        node.get_logger().info(
            'Finger close commands sent. Check actual gear grasp.'
        )
        node.get_logger().info(
            'Lifting motion has NOT been started.'
        )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
