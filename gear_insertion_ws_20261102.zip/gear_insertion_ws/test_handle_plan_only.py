#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import MotionPlanRequest, Constraints, JointConstraint


class HandlePlanOnlyTest(Node):

    def __init__(self):
        super().__init__('handle_plan_only_test')

        self.latest_joint_state = None

        self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10,
        )

        self.client = self.create_client(
            GetMotionPlan,
            '/plan_kinematic_path',
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg


def main():

    rclpy.init()
    node = HandlePlanOnlyTest()

    try:

        node.get_logger().info(
            'Waiting for /joint_states...'
        )

        for _ in range(50):
            rclpy.spin_once(node, timeout_sec=0.1)

            if node.latest_joint_state is not None:
                break

        if node.latest_joint_state is None:
            node.get_logger().error(
                'No joint state received. Aborting.'
            )
            return

        joint_state = node.latest_joint_state

        arm_names = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7',
        ]

        state_map = dict(
            zip(joint_state.name, joint_state.position)
        )

        if not all(name in state_map for name in arm_names):
            node.get_logger().error(
                'Missing Panda arm joints. Aborting.'
            )
            return

        node.get_logger().info(
            'Current joint state received.'
        )

        node.get_logger().info(
            'Waiting for /plan_kinematic_path...'
        )

        if not node.client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error(
                '/plan_kinematic_path is unavailable. Aborting.'
            )
            return

        request = GetMotionPlan.Request()

        plan = MotionPlanRequest()

        plan.group_name = 'panda_arm'
        plan.pipeline_id = 'ompl'
        plan.planner_id = 'RRTConnect'

        plan.num_planning_attempts = 1
        plan.allowed_planning_time = 2.0

        plan.max_velocity_scaling_factor = 0.1
        plan.max_acceleration_scaling_factor = 0.1

        # ---------------------------------------------------------
        # Current Gazebo joint state を明示的に開始状態として使用
        # ---------------------------------------------------------

        plan.start_state.joint_state.name = arm_names

        plan.start_state.joint_state.position = [
            state_map[name]
            for name in arm_names
        ]

        plan.start_state.is_diff = False

        # ---------------------------------------------------------
        # READY姿勢を目標にする
        # ---------------------------------------------------------

        ready_positions = [
            -1.3474,
            -0.1975,
            1.0743,
            -1.0438,
            0.2123,
            0.9595,
            2.1980,
        ]

        constraints = Constraints()

        for name, position in zip(
            arm_names,
            ready_positions
        ):

            goal = JointConstraint()

            goal.joint_name = name
            goal.position = position

            goal.tolerance_above = 0.01
            goal.tolerance_below = 0.01
            goal.weight = 1.0

            constraints.joint_constraints.append(goal)

        plan.goal_constraints.append(constraints)

        request.motion_plan_request = plan

        node.get_logger().info(
            '=========================================='
        )

        node.get_logger().info(
            'PLAN ONLY TEST'
        )

        node.get_logger().info(
            'Start: CURRENT Gazebo joint state'
        )

        node.get_logger().info(
            'Goal : IK solution near insertion gear handle'
        )

        node.get_logger().info(
            'NO TRAJECTORY EXECUTION'
        )

        node.get_logger().info(
            '=========================================='
        )

        future = node.client.call_async(request)

        while rclpy.ok() and not future.done():
            rclpy.spin_once(
                node,
                timeout_sec=0.1
            )

        if not future.done():
            node.get_logger().error(
                'Planning request did not complete.'
            )
            return

        response = future.result()

        if response is None:
            node.get_logger().error(
                'Planning service returned no response.'
            )
            return

        result = response.motion_plan_response

        node.get_logger().info(
            f'MoveIt error code: {result.error_code.val}'
        )

        node.get_logger().info(
            f'MoveIt error message: {result.error_code}'
        )

        node.get_logger().info(
            f'Planning time: '
            f'{result.planning_time:.3f} seconds'
        )

        node.get_logger().info(
            f'Trajectory points: '
            f'{len(result.trajectory.joint_trajectory.points)}'
        )

        if result.error_code.val == 1:

            node.get_logger().info(
                '=========================================='
            )

            node.get_logger().info(
                'PLAN ONLY: SUCCESS'
            )

            node.get_logger().info(
                'Handle-target trajectory was generated.'
            )

            node.get_logger().info(
                'Nothing was executed.'
            )

            node.get_logger().info(
                '=========================================='
            )

        else:

            node.get_logger().error(
                '=========================================='
            )

            node.get_logger().error(
                'PLAN ONLY: FAILED'
            )

            node.get_logger().error(
                'No trajectory was executed.'
            )

            node.get_logger().error(
                '=========================================='
            )

    finally:

        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
