import rclpy
from rclpy.node import Node

from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState


ARM_NAMES = [
    'panda_joint1',
    'panda_joint2',
    'panda_joint3',
    'panda_joint4',
    'panda_joint5',
    'panda_joint6',
    'panda_joint7',
]

# 現在のゼロ姿勢からREADY姿勢へ向かう途中の候補
CANDIDATES = [
    ('A', [0.0, -0.3, 0.0, -2.2, 0.0, 1.5, 0.785]),
    ('B', [0.0, -0.5, 0.0, -2.2, 0.0, 1.5, 0.785]),
    ('C', [0.0, -0.7, 0.0, -2.2, 0.0, 1.5, 0.785]),
    ('D', [0.0, -0.5, 0.0, -1.8, 0.0, 1.5, 0.785]),
    ('E', [0.0, -0.7, 0.0, -1.8, 0.0, 1.5, 0.785]),
]

class PostureChecker(Node):
    def __init__(self):
        super().__init__('intermediate_posture_checker')

        self.latest_joint_state = None

        self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10,
        )

        self.client = self.create_client(
            GetStateValidity,
            '/check_state_validity',
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg


def main():
    rclpy.init()
    node = PostureChecker()

    try:
        node.get_logger().info('Waiting for /joint_states...')

        for _ in range(50):
            rclpy.spin_once(node, timeout_sec=0.1)
            if node.latest_joint_state is not None:
                break

        if node.latest_joint_state is None:
            node.get_logger().error('No joint state received.')
            return

        node.get_logger().info(
            'Waiting for /check_state_validity...'
        )

        if not node.client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error(
                '/check_state_validity is unavailable.'
            )
            return

        for label, positions in CANDIDATES:
            robot_state = RobotState()
            robot_state.joint_state.name = ARM_NAMES
            robot_state.joint_state.position = positions

            request = GetStateValidity.Request()
            request.robot_state = robot_state
            request.group_name = 'panda_arm'

            future = node.client.call_async(request)

            while rclpy.ok() and not future.done():
                rclpy.spin_once(node, timeout_sec=0.1)

            if not future.done():
                node.get_logger().error(
                    f'{label}: request timed out'
                )
                continue

            response = future.result()

            if response is None:
                node.get_logger().error(
                    f'{label}: no response'
                )
                continue

            if response.valid:
                node.get_logger().info(
                    f'{label}: VALID  joints={positions}'
                )
            else:
                node.get_logger().warning(
                    f'{label}: INVALID'
                )

                for contact in response.contacts:
                    node.get_logger().warning(
                        f'  {contact.contact_body_1} <-> '
                        f'{contact.contact_body_2}'
                    )

        node.get_logger().info(
            'Inspection finished. No motion commands were sent.'
        )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
