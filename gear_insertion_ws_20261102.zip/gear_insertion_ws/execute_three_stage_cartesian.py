import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from sensor_msgs.msg import JointState
from geometry_msgs.msg import Pose
from moveit_msgs.srv import GetCartesianPath
from moveit_msgs.msg import RobotState
from control_msgs.action import FollowJointTrajectory


JOINT_NAMES = [
    'panda_joint1', 'panda_joint2', 'panda_joint3',
    'panda_joint4', 'panda_joint5', 'panda_joint6',
    'panda_joint7',
    'panda_finger_joint1', 'panda_finger_joint2',
]

ARM_NAMES = JOINT_NAMES[:7]

QUATERNION = (0.5835, 0.5837, 0.3993, -0.3992)

TARGETS = [
    (0.550, -0.500, 0.911),
    (0.550, -0.500, 0.961),
    (0.550, -0.450, 0.961),
]


class ExecuteCartesian(Node):
    def __init__(self):
        super().__init__('execute_three_stage_cartesian')

        self.latest_state = None

        self.create_subscription(
            JointState,
            '/merged_joint_states',
            self.joint_callback,
            10
        )

        self.cartesian_client = self.create_client(
            GetCartesianPath,
            '/compute_cartesian_path'
        )

        self.action_client = ActionClient(
            self,
            FollowJointTrajectory,
            '/panda_arm_controller/follow_joint_trajectory'
        )

    def joint_callback(self, msg):
        self.latest_state = dict(zip(msg.name, msg.position))

    def run(self):
        self.get_logger().info(
            'Waiting for the latest joint state...'
        )

        deadline = time.monotonic() + 15.0
        while self.latest_state is None and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.2)

        if self.latest_state is None:
            self.get_logger().error('No joint state received. Aborting.')
            return

        if not all(name in self.latest_state for name in JOINT_NAMES):
            self.get_logger().error(
                'Some arm or finger joints are missing. Aborting.'
            )
            return

        current = [self.latest_state[name] for name in JOINT_NAMES]

        if not self.cartesian_client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error(
                'Cartesian path service unavailable. Aborting.'
            )
            return

        if not self.action_client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error(
                'Trajectory action server unavailable. Aborting.'
            )
            return

        request = GetCartesianPath.Request()
        request.header.frame_id = 'world'

        request.start_state = RobotState()
        request.start_state.joint_state.name = JOINT_NAMES
        request.start_state.joint_state.position = current
        request.start_state.is_diff = False

        request.group_name = 'panda_arm'
        request.link_name = 'panda_hand'

        for x, y, z in TARGETS:
            pose = Pose()
            pose.position.x = x
            pose.position.y = y
            pose.position.z = z

            pose.orientation.x = QUATERNION[0]
            pose.orientation.y = QUATERNION[1]
            pose.orientation.z = QUATERNION[2]
            pose.orientation.w = QUATERNION[3]

            request.waypoints.append(pose)

        request.max_step = 0.01
        request.jump_threshold = 0.0
        request.avoid_collisions = True
        request.max_velocity_scaling_factor = 0.1
        request.max_acceleration_scaling_factor = 0.1

        self.get_logger().info(
            'Planning Cartesian path from the latest joint state...'
        )

        future = self.cartesian_client.call_async(request)
        rclpy.spin_until_future_complete(
            self, future, timeout_sec=60.0
        )

        if not future.done() or future.result() is None:
            self.get_logger().error(
                'Cartesian planning timed out. No movement.'
            )
            return

        response = future.result()
        trajectory = response.solution.joint_trajectory

        self.get_logger().info(
            f'Planning error code: {response.error_code.val}'
        )
        self.get_logger().info(
            f'Cartesian fraction: {response.fraction:.4f}'
        )
        self.get_logger().info(
            f'Trajectory points: {len(trajectory.points)}'
        )

        if response.error_code.val != 1 or response.fraction < 0.999:
            self.get_logger().error(
                'Planning incomplete. No movement.'
            )
            return

        if not trajectory.points:
            self.get_logger().error(
                'Trajectory is empty. No movement.'
            )
            return

        first = trajectory.points[0].positions
        if len(first) != len(trajectory.joint_names):
            self.get_logger().error(
                'Unexpected trajectory start point. No movement.'
            )
            return

        current_arm = [self.latest_state[name] for name in ARM_NAMES]
        start_arm = [
            first[trajectory.joint_names.index(name)]
            for name in ARM_NAMES
        ]

        max_difference = max(
            abs(a - b) for a, b in zip(current_arm, start_arm)
        )

        self.get_logger().info(
            f'Max start-state difference: {max_difference:.6f} rad'
        )

        if max_difference > 0.02:
            self.get_logger().error(
                'Start state changed too much. No movement.'
            )
            return

        self.get_logger().info(
            'Cartesian plan passed checks. Sending trajectory.'
        )

        goal = FollowJointTrajectory.Goal()
        goal.trajectory = trajectory
        goal.goal_time_tolerance.sec = 10

        send_future = self.action_client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, send_future)

        goal_handle = send_future.result()

        if goal_handle is None or not goal_handle.accepted:
            self.get_logger().error(
                'Trajectory goal rejected.'
            )
            return

        self.get_logger().info(
            'Trajectory accepted. Panda is moving.'
        )

        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(
            self, result_future, timeout_sec=90.0
        )

        if not result_future.done():
            self.get_logger().error(
                'Execution result timeout. Check the simulator.'
            )
            return

        result = result_future.result().result

        self.get_logger().info(
            f'Controller result error_code: {result.error_code}'
        )
        self.get_logger().info(
            f'Controller message: {result.error_string}'
        )

        if result.error_code == 0:
            self.get_logger().info(
                'THREE-STAGE CARTESIAN MOTION COMPLETED'
            )
        else:
            self.get_logger().error(
                'Trajectory execution did not complete successfully.'
            )


def main():
    rclpy.init()
    node = ExecuteCartesian()

    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
