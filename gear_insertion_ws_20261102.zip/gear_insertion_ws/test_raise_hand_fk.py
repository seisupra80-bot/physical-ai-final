import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetPositionFK


class RaiseHandFK(Node):
    def __init__(self):
        super().__init__('raise_hand_fk')
        self.client = self.create_client(GetPositionFK, '/compute_fk')


def main():
    rclpy.init()
    node = RaiseHandFK()

    try:
        if not node.client.wait_for_service(timeout_sec=10.0):
            node.get_logger().error('FK service unavailable.')
            return

        names = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7',
        ]

        candidates = [-0.6, -0.8, -1.0]

        for j2 in candidates:
            request = GetPositionFK.Request()
            request.header.frame_id = 'world'
            request.fk_link_names = ['panda_hand']

            request.robot_state.joint_state.name = names
            request.robot_state.joint_state.position = [
                0.0,
                j2,
                0.0,
                -1.4,
                0.0,
                1.8,
                0.785,
            ]
            request.robot_state.is_diff = False

            future = node.client.call_async(request)

            while rclpy.ok() and not future.done():
                rclpy.spin_once(node, timeout_sec=0.1)

            response = future.result()

            if response is None or len(response.pose_stamped) == 0:
                node.get_logger().error(
                    f'J2={j2:.2f}: FK failed'
                )
                continue

            p = response.pose_stamped[0].pose.position

            node.get_logger().info(
                f'J2={j2:.2f} -> '
                f'hand position: '
                f'x={p.x:.4f}, y={p.y:.4f}, z={p.z:.4f} m'
            )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
