import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from sensor_msgs.msg import JointState
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from builtin_interfaces.msg import Duration


JOINT_NAMES = [
    'panda_joint1',
    'panda_joint2',
    'panda_joint3',
    'panda_joint4',
    'panda_joint5',
    'panda_joint6',
    'panda_joint7',
]

GOAL_A = [0.0, -0.3, 0.0, -2.2, 0.0, 1.5, 0.785]


class MoveToCandidateA(Node):

    def __init__(self):
        super().__init__('move_to_candidate_a')

        self.latest_joint_state = None

        self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10,
        )

        self.client = ActionClient(
            self,
            FollowJointTrajectory,
            '/panda_arm_controller/follow_joint_trajectory',
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg


def main():
    rclpy.init()
    node = MoveToCandidateA()

    try:
        node.get_logger().info('Waiting for joint states...')

        for _ in range(50):
            rclpy.spin_once(node, timeout_sec=0.1)
            if node.latest_joint_state is not None:
                break

        if node.latest_joint_state is None:
            node.get_logger().error('No joint states. Aborting.')
            return

        state_map = dict(zip(
            node.latest_joint_state.name,
            node.latest_joint_state.position,
        ))

        if not all(name in state_map for name in JOINT_NAMES):
            node.get_logger().error('Missing arm joints. Aborting.')
            return

        start = [state_map[name] for name in JOINT_NAMES]

        node.get_logger().info(f'Start positions: {start}')
        node.get_logger().info(f'Goal positions: {GOAL_A}')

        node.get_logger().info('Waiting for trajectory action server...')

        if not node.client.wait_for_server(timeout_sec=5.0):
            node.get_logger().error('Action server unavailable.')
            return

        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = JOINT_NAMES

        # Three interpolated points, followed by the final target.
        for i, t in enumerate([0.25, 0.5, 0.75, 1.0], start=1):
            point = JointTrajectoryPoint()
            point.positions = [
                s + (g - s) * t
                for s, g in zip(start, GOAL_A)
            ]
            point.velocities = [0.0] * 7
            point.time_from_start = Duration(
                sec=i * 2,
                nanosec=0,
            )
            goal.trajectory.points.append(point)

        node.get_logger().warn(
            'About to send a direct 8-second trajectory to candidate A.'
        )

        send_future = node.client.send_goal_async(goal)
        rclpy.spin_until_future_complete(node, send_future)

        goal_handle = send_future.result()

        if goal_handle is None or not goal_handle.accepted:
            node.get_logger().error('Trajectory goal rejected.')
            return

        node.get_logger().info('Goal accepted. Waiting for completion...')

        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(node, result_future)

        wrapped_result = result_future.result()

        if wrapped_result is not None:
            result = wrapped_result.result
            node.get_logger().info(
                f'Trajectory result error_code: {result.error_code}'
            )
            node.get_logger().info(result.error_string)

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
