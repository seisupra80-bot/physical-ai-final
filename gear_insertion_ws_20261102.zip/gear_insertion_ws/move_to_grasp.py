import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from builtin_interfaces.msg import Duration


JOINT_NAMES = [
    'panda_joint1',
    'panda_joint2',
    'panda_joint3',
    'panda_joint4',
    'panda_joint5',
    'panda_joint6',
    'panda_joint7',
]

GRASP = [
    0.0,
    -0.5534,
    0.0,
    -1.7639,
    0.0,
    2.4105,
    0.785,
]


class MoveToGrasp(Node):
    def __init__(self):
        super().__init__('move_to_grasp')

        self.client = ActionClient(
            self,
            FollowJointTrajectory,
            '/panda_arm_controller/follow_joint_trajectory'
        )

    def run(self):
        self.get_logger().info(
            'Waiting for arm trajectory action server...'
        )

        if not self.client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error(
                'Trajectory action server unavailable'
            )
            return

        goal = FollowJointTrajectory.Goal()
        trajectory = goal.trajectory
        trajectory.joint_names = JOINT_NAMES

        point = JointTrajectoryPoint()
        point.positions = GRASP
        point.velocities = [0.0] * 7
        point.time_from_start = Duration(
            sec=20,
            nanosec=0
        )
        trajectory.points.append(point)

        goal.goal_time_tolerance = Duration(
            sec=10,
            nanosec=0
        )

        self.get_logger().info(
            'Sending current pose -> GRASP trajectory (20 seconds)'
        )

        send_future = self.client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, send_future)

        goal_handle = send_future.result()

        if goal_handle is None or not goal_handle.accepted:
            self.get_logger().error('Trajectory goal rejected')
            return

        self.get_logger().info('Trajectory goal accepted')

        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)

        result = result_future.result()

        if result is not None and result.result.error_code == 0:
            self.get_logger().info(
                'ARRIVED AT GRASP CANDIDATE'
            )
        elif result is not None:
            self.get_logger().error(
                f'Trajectory failed: error_code='
                f'{result.result.error_code}, '
                f'{result.result.error_string}'
            )
        else:
            self.get_logger().error('No trajectory result received')


def main():
    rclpy.init()
    node = MoveToGrasp()

    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
