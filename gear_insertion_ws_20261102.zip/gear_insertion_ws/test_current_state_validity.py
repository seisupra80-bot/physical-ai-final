import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState

class StateValidityTest(Node):
    def __init__(self):
        super().__init__('state_validity_test')
        self.latest = None
        self.create_subscription(
            JointState, '/joint_states',
            self.state_callback, 10
        )
        self.client = self.create_client(
            GetStateValidity, '/check_state_validity'
        )

    def state_callback(self, msg):
        self.latest = msg

def main():
    rclpy.init()
    node = StateValidityTest()

    try:
        node.get_logger().info('Waiting for /joint_states...')
        for _ in range(50):
            rclpy.spin_once(node, timeout_sec=0.1)
            if node.latest is not None:
                break

        if node.latest is None:
            node.get_logger().error('No joint state received.')
            return

        if not node.client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error('/check_state_validity unavailable.')
            return

        request = GetStateValidity.Request()
        request.robot_state = RobotState()
        request.robot_state.joint_state = node.latest
        request.group_name = 'panda_arm'

        future = node.client.call_async(request)
        while rclpy.ok() and not future.done():
            rclpy.spin_once(node, timeout_sec=0.1)

        response = future.result()
        if response is None:
            node.get_logger().error('No response.')
            return

        node.get_logger().info(
            f'Current state valid: {response.valid}'
        )
        for contact in response.contacts:
            node.get_logger().info(
                f'Contact: {contact.contact_body_1} - '
                f'{contact.contact_body_2}'
            )
        for pair in response.cost_sources:
            node.get_logger().info(f'Cost source: {pair}')

    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
