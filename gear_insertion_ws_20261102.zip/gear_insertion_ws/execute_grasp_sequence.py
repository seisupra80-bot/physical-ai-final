import time
import subprocess

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from control_msgs.action import FollowJointTrajectory

from moveit_msgs.srv import GetPositionFK, GetCartesianPath
from moveit_msgs.msg import RobotState
from geometry_msgs.msg import Pose


JOINT_NAMES = [
    'panda_joint1',
    'panda_joint2',
    'panda_joint3',
    'panda_joint4',
    'panda_joint5',
    'panda_joint6',
    'panda_joint7',
]

GRASP_CURRENT = [
    -0.0000786,
    -0.5258634,
     0.0000402,
    -1.5513850,
     0.0000625,
     2.2663536,
     0.7853629,
]

# Panda finger opening.
FINGER_OPEN = 0.040
FINGER_CLOSED = 0.028


class GraspSequence(Node):

    def __init__(self):
        super().__init__('grasp_sequence')

        self.joint_state = None
        self.finger_positions = None

        self.create_subscription(
            JointState,
            '/merged_joint_states',
            self.joint_callback,
            10
        )

        self.action_client = ActionClient(
            self,
            FollowJointTrajectory,
            '/panda_arm_controller/follow_joint_trajectory'
        )

        self.fk_client = self.create_client(
            GetPositionFK,
            '/compute_fk'
        )

        self.cartesian_client = self.create_client(
            GetCartesianPath,
            '/compute_cartesian_path'
        )

    def joint_callback(self, msg):
        values = dict(zip(msg.name, msg.position))

        if all(name in values for name in JOINT_NAMES):
            self.joint_state = [
                values[name] for name in JOINT_NAMES
            ]

        finger_names = [
            'panda_finger_joint1',
            'panda_finger_joint2',
        ]

        if all(name in values for name in finger_names):
            self.finger_positions = [
                values[name] for name in finger_names
            ]

    def wait_joint_state(self):
        self.get_logger().info(
            'Waiting for /merged_joint_states...'
        )

        end = time.time() + 5.0

        while rclpy.ok() and time.time() < end:
            rclpy.spin_once(self, timeout_sec=0.1)

            if self.joint_state is not None:
                self.get_logger().info(
                    'Current joint state received.'
                )
                self.get_logger().info(
                    'Current: ' +
                    ', '.join(
                        f'{x:.6f}' for x in self.joint_state
                    )
                )
                return True

        self.get_logger().error(
            'Timeout waiting for /merged_joint_states.'
        )
        return False

    # ------------------------------------------------------------
    # Gazebo finger command
    # ------------------------------------------------------------

    def set_fingers(self, value):

        self.get_logger().info(
            f'Finger command: {value:.3f} m'
        )

        commands = [
            '/panda_left_finger_cmd',
            '/panda_right_finger_cmd',
        ]

        for topic in commands:
            cmd = [
                'gz', 'topic', '-t', topic,
                '-m', 'gz.msgs.Double',
                '-p', f'data: {value}'
            ]

            try:
                subprocess.run(
                    cmd,
                    check=True,
                    timeout=3.0,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE,
                    text=True
                )
            except Exception as e:
                self.get_logger().error(
                    f'Finger command failed: {topic}: {e}'
                )
                return False

        self.get_logger().info(
            'Waiting for both fingers to reach target...'
        )

        deadline = time.time() + 3.0
        tolerance = 0.002

        while rclpy.ok() and time.time() < deadline:
            rclpy.spin_once(self, timeout_sec=0.1)

            if self.finger_positions is None:
                continue

            errors = [
                abs(position - value)
                for position in self.finger_positions
            ]

            if all(error <= tolerance for error in errors):
                self.get_logger().info(
                    'Both fingers reached target: '
                    + ', '.join(
                        f'{x:.4f} m' for x in self.finger_positions
                    )
                )
                return True

            # During closing, allow the fingers to stop at the gear.
            if value < FINGER_OPEN - tolerance:
                if all(position < FINGER_OPEN - 0.002
                       for position in self.finger_positions):
                    self.get_logger().info(
                        'Both fingers moved inward; possible object contact: '
                        + ', '.join(
                            f'{x:.4f} m' for x in self.finger_positions
                        )
                    )
                    return True

        actual = (
            'not received'
            if self.finger_positions is None
            else ', '.join(
                f'{x:.4f} m' for x in self.finger_positions
            )
        )

        self.get_logger().error(
            f'Finger position timeout. Target={value:.4f} m, '
            f'actual={actual}'
        )
        return False

    # ------------------------------------------------------------
    # Joint trajectory
    # ------------------------------------------------------------

    def move_to_joint_pose(self, target, duration=4.0):

        self.get_logger().info(
            'Moving arm to GRASP_CURRENT...'
        )

        if not self.action_client.wait_for_server(
            timeout_sec=5.0
        ):
            self.get_logger().error(
                'FollowJointTrajectory action server unavailable.'
            )
            return False

        goal = FollowJointTrajectory.Goal()

        traj = JointTrajectory()
        traj.joint_names = JOINT_NAMES

        point = JointTrajectoryPoint()
        point.positions = target
        point.velocities = [0.0] * 7

        sec = int(duration)
        nanosec = int(
            (duration - sec) * 1e9
        )

        point.time_from_start.sec = sec
        point.time_from_start.nanosec = nanosec

        traj.points.append(point)
        goal.trajectory = traj

        future = self.action_client.send_goal_async(goal)

        rclpy.spin_until_future_complete(
            self,
            future,
            timeout_sec=5.0
        )

        if not future.done():
            self.get_logger().error(
                'Failed to send trajectory goal.'
            )
            return False

        handle = future.result()

        if not handle.accepted:
            self.get_logger().error(
                'Trajectory goal rejected.'
            )
            return False

        self.get_logger().info(
            'GRASP trajectory accepted.'
        )

        result_future = handle.get_result_async()

        rclpy.spin_until_future_complete(
            self,
            result_future,
            timeout_sec=30.0
        )

        if not result_future.done():
            self.get_logger().error(
                'Trajectory execution timeout.'
            )
            return False

        result = result_future.result().result

        if result.error_code != 0:
            self.get_logger().error(
                f'Trajectory failed: '
                f'error_code={result.error_code}'
            )
            return False

        time.sleep(0.5)

        self.get_logger().info(
            'GRASP_CURRENT reached.'
        )

        return True

    # ------------------------------------------------------------
    # FK
    # ------------------------------------------------------------

    def get_hand_pose(self):

        self.get_logger().info(
            'Getting current panda_hand pose...'
        )

        if not self.fk_client.wait_for_service(
            timeout_sec=5.0
        ):
            self.get_logger().error(
                '/compute_fk service unavailable.'
            )
            return None

        request = GetPositionFK.Request()

        request.header.frame_id = 'world'
        request.fk_link_names = ['panda_hand']

        state = RobotState()

        state.joint_state.name = JOINT_NAMES
        state.joint_state.position = self.joint_state

        request.robot_state = state

        future = self.fk_client.call_async(request)

        rclpy.spin_until_future_complete(
            self,
            future,
            timeout_sec=5.0
        )

        if not future.done():
            self.get_logger().error(
                'FK request timeout.'
            )
            return None

        response = future.result()

        if response.error_code.val != 1:
            self.get_logger().error(
                f'FK failed: error_code='
                f'{response.error_code.val}'
            )
            return None

        pose = response.pose_stamped[0].pose

        self.get_logger().info(
            'panda_hand pose: '
            f'x={pose.position.x:.4f}, '
            f'y={pose.position.y:.4f}, '
            f'z={pose.position.z:.4f}'
        )

        return pose

    # ------------------------------------------------------------
    # Cartesian motion
    # ------------------------------------------------------------

    def execute_cartesian(self, waypoints):

        self.get_logger().info(
            'Computing Cartesian path...'
        )

        if not self.cartesian_client.wait_for_service(
            timeout_sec=5.0
        ):
            self.get_logger().error(
                '/compute_cartesian_path unavailable.'
            )
            return False

        # Get the latest joint state.
        rclpy.spin_once(self, timeout_sec=0.2)

        if self.joint_state is None:
            self.get_logger().error(
                'No current joint state.'
            )
            return False

        request = GetCartesianPath.Request()

        request.header.frame_id = 'world'
        request.group_name = 'panda_arm'
        request.link_name = 'panda_hand'

        state = RobotState()
        state.joint_state.name = JOINT_NAMES
        state.joint_state.position = self.joint_state
        request.start_state = state

        request.waypoints = waypoints

        request.max_step = 0.005
        request.jump_threshold = 0.0
        request.avoid_collisions = True

        request.max_velocity_scaling_factor = 0.1
        request.max_acceleration_scaling_factor = 0.1

        future = self.cartesian_client.call_async(request)

        rclpy.spin_until_future_complete(
            self,
            future,
            timeout_sec=10.0
        )

        if not future.done():
            self.get_logger().error(
                'Cartesian path request timeout.'
            )
            return False

        response = future.result()

        self.get_logger().info(
            f'Cartesian error code: '
            f'{response.error_code.val}'
        )

        self.get_logger().info(
            f'Cartesian fraction: '
            f'{response.fraction:.4f}'
        )

        if response.error_code.val != 1:
            self.get_logger().error(
                'Cartesian path planning failed.'
            )
            return False

        if response.fraction < 0.999:
            self.get_logger().error(
                'Cartesian path fraction < 0.999.'
            )
            return False

        if len(response.solution.joint_trajectory.points) == 0:
            self.get_logger().error(
                'Cartesian trajectory is empty.'
            )
            return False

        goal = FollowJointTrajectory.Goal()
        goal.trajectory = response.solution.joint_trajectory

        self.get_logger().info(
            f'Executing Cartesian trajectory: '
            f'{len(goal.trajectory.points)} points'
        )

        future = self.action_client.send_goal_async(goal)

        rclpy.spin_until_future_complete(
            self,
            future,
            timeout_sec=5.0
        )

        if not future.done():
            self.get_logger().error(
                'Failed to send Cartesian trajectory.'
            )
            return False

        handle = future.result()

        if not handle.accepted:
            self.get_logger().error(
                'Cartesian trajectory rejected.'
            )
            return False

        result_future = handle.get_result_async()

        rclpy.spin_until_future_complete(
            self,
            result_future,
            timeout_sec=15.0
        )

        if not result_future.done():
            self.get_logger().error(
                'Cartesian execution timeout.'
            )
            return False

        result = result_future.result().result

        if result.error_code != 0:
            self.get_logger().error(
                f'Cartesian execution failed: '
                f'error_code={result.error_code}'
            )
            return False

        time.sleep(0.5)

        return True

    # ------------------------------------------------------------
    # Main sequence
    # ------------------------------------------------------------

    def run(self):

        self.get_logger().info(
            '======================================'
        )
        self.get_logger().info(
            ' GRASP / LIFT / LOWER SEQUENCE START'
        )
        self.get_logger().info(
            '======================================'
        )

        if not self.wait_joint_state():
            return False

        # --------------------------------------------------------
        # STEP 1
        # --------------------------------------------------------

        self.get_logger().info(
            'STEP 1: OPEN HAND'
        )

        if not self.set_fingers(FINGER_OPEN):
            return False

        self.get_logger().info(
            'Hand fully open.'
        )

        # --------------------------------------------------------
        # STEP 2
        # --------------------------------------------------------

        self.get_logger().info(
            'STEP 2: MOVE TO GRASP_CURRENT'
        )

        if not self.move_to_joint_pose(
            GRASP_CURRENT,
            duration=4.0
        ):
            return False

        # --------------------------------------------------------
        # STEP 3
        # --------------------------------------------------------

        self.get_logger().info(
            'STEP 3: CLOSE FINGERS AND GRASP SHAFT'
        )

        if not self.set_fingers(FINGER_CLOSED):
            return False

        self.get_logger().info(
            'Shaft grasped.'
        )

        time.sleep(1.0)

        # Get actual hand pose at grasp.
        rclpy.spin_once(self, timeout_sec=0.2)

        grasp_pose = self.get_hand_pose()

        if grasp_pose is None:
            return False

        # --------------------------------------------------------
        # STEP 4
        # +Z 5 cm
        # --------------------------------------------------------

        self.get_logger().info(
            'STEP 4: LIFT +Z 5 cm'
        )

        lift_pose = Pose()

        lift_pose.position.x = grasp_pose.position.x
        lift_pose.position.y = grasp_pose.position.y
        lift_pose.position.z = grasp_pose.position.z + 0.050

        lift_pose.orientation = grasp_pose.orientation

        if not self.execute_cartesian(
            [lift_pose]
        ):
            return False

        self.get_logger().info(
            'Lift +5 cm completed.'
        )

        # --------------------------------------------------------
        # HOLD FOR 10 SECONDS
        # --------------------------------------------------------

        self.get_logger().info(
            'STEP 5: HOLD LIFTED POSITION FOR 10 SECONDS'
        )

        time.sleep(10.0)

        self.get_logger().info(
            '10-second hold completed.'
        )

        # --------------------------------------------------------
        # STEP 6
        # -Z 5 cm and +Y 0.5 cm
        # --------------------------------------------------------

        self.get_logger().info(
            'STEP 6: LOWER -Z 5 cm + MOVE +Y 0.5 cm'
        )

        lower_pose = Pose()

        lower_pose.position.x = grasp_pose.position.x
        lower_pose.position.y = grasp_pose.position.y + 0.005
        lower_pose.position.z = grasp_pose.position.z

        lower_pose.orientation = grasp_pose.orientation

        if not self.execute_cartesian(
            [lower_pose]
        ):
            return False

        self.get_logger().info(
            'Lower -5 cm / Y +0.5 cm completed.'
        )

        self.get_logger().info(
            '======================================'
        )
        self.get_logger().info(
            ' SEQUENCE COMPLETED SUCCESSFULLY'
        )
        self.get_logger().info(
            '======================================'
        )

        return True


def main():

    rclpy.init()

    node = GraspSequence()

    try:
        success = node.run()

        if success:
            node.get_logger().info(
                'ALL 5 STEPS COMPLETED.'
            )
        else:
            node.get_logger().error(
                'SEQUENCE FAILED.'
            )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
