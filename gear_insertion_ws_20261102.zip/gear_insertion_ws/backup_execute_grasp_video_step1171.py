import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectoryPoint
from control_msgs.action import FollowJointTrajectory

from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import MotionPlanRequest, Constraints, JointConstraint


ARM_JOINTS = [
    'panda_joint1', 'panda_joint2', 'panda_joint3',
    'panda_joint4', 'panda_joint5', 'panda_joint6',
    'panda_joint7'
]

FINGER_JOINTS = [
    'panda_finger_joint1',
    'panda_finger_joint2'
]

READY = [
    0.0, -0.785, 0.0, -2.356,
    0.0, 1.571, 0.785
]

GRASP = [
    -0.0000786,
    -0.5258634,
     0.0000402,
    -1.5513850,
     0.0000625,
     2.2663536,
     0.7853629
]


class ExecuteGraspVideo(Node):

    def __init__(self):
        super().__init__('execute_grasp_video')

        self.latest = None

        self.create_subscription(
            JointState, '/merged_joint_states',
            self.joint_callback, 10
        )

        self.plan_client = self.create_client(
            GetMotionPlan, '/plan_kinematic_path'
        )

        self.arm_action = ActionClient(
            self, FollowJointTrajectory,
            '/panda_arm_controller/follow_joint_trajectory'
        )

        self.hand_action = ActionClient(
            self, FollowJointTrajectory,
            '/panda_hand_controller/follow_joint_trajectory'
        )

    def joint_callback(self, msg):
        self.latest = msg

    def wait_for_state(self):
        self.get_logger().info('Waiting for joint states...')
        for _ in range(50):
            rclpy.spin_once(self, timeout_sec=0.1)
            if self.latest is not None:
                state = dict(zip(
                    self.latest.name, self.latest.position
                ))
                if all(j in state for j in ARM_JOINTS):
                    return state
        return None

    def plan_to(self, start, goal):
        request = GetMotionPlan.Request()
        plan = MotionPlanRequest()

        plan.group_name = 'panda_arm'
        plan.pipeline_id = 'ompl'
        plan.planner_id = 'RRTConnect'
        plan.num_planning_attempts = 1
        plan.allowed_planning_time = 3.0
        plan.max_velocity_scaling_factor = 0.1
        plan.max_acceleration_scaling_factor = 0.1

        plan.start_state.joint_state.name = ARM_JOINTS
        plan.start_state.joint_state.position = [
            start[j] for j in ARM_JOINTS
        ]
        plan.start_state.is_diff = False

        constraints = Constraints()
        for name, position in zip(ARM_JOINTS, goal):
            jc = JointConstraint()
            jc.joint_name = name
            jc.position = position
            jc.tolerance_above = 0.02
            jc.tolerance_below = 0.02
            jc.weight = 1.0
            constraints.joint_constraints.append(jc)

        plan.goal_constraints.append(constraints)
        request.motion_plan_request = plan

        future = self.plan_client.call_async(request)
        while rclpy.ok() and not future.done():
            rclpy.spin_once(self, timeout_sec=0.1)

        if not future.done() or future.result() is None:
            return None

        result = future.result().motion_plan_response
        if result.error_code.val != 1:
            self.get_logger().error(
                f'Planning failed: {result.error_code.val}'
            )
            return None

        return result.trajectory.joint_trajectory

    def execute_arm(self, trajectory):
        goal = FollowJointTrajectory.Goal()
        goal.trajectory = trajectory

        future = self.arm_action.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, future)
        handle = future.result()

        if handle is None or not handle.accepted:
            self.get_logger().error('Arm trajectory rejected.')
            return False

        result_future = handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)

        result = result_future.result()
        return result is not None and result.result.error_code == 0

    def close_hand(self):
        trajectory = __import__(
            'trajectory_msgs.msg', fromlist=['JointTrajectory']
        ).JointTrajectory()

        trajectory.joint_names = FINGER_JOINTS

        point = JointTrajectoryPoint()
        point.positions = [0.015, 0.015]
        point.velocities = [0.02, 0.02]
        point.time_from_start.sec = 2

        trajectory.points.append(point)

        goal = FollowJointTrajectory.Goal()
        goal.trajectory = trajectory

        future = self.hand_action.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, future)
        handle = future.result()

        if handle is None or not handle.accepted:
            self.get_logger().error('Gripper command rejected.')
            return False

        result_future = handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)

        result = result_future.result()
        return result is not None and result.result.error_code == 0


def main():
    rclpy.init()
    node = ExecuteGraspVideo()

    try:
        # 事前確認：この段階ではロボットを動かさない
        state = node.wait_for_state()
        if state is None:
            node.get_logger().error('Joint states unavailable. STOP.')
            return

        if not node.plan_client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error('MoveIt planning service unavailable. STOP.')
            return

        if not node.arm_action.wait_for_server(timeout_sec=5.0):
            node.get_logger().error('Arm action server unavailable. STOP.')
            return

        if not node.hand_action.wait_for_server(timeout_sec=5.0):
            node.get_logger().error(
                'Gripper action server unavailable. STOP. No motion executed.'
            )
            return

        node.get_logger().info('All required action servers are available.')

        # 1. 現在姿勢からReady姿勢へ
        node.get_logger().info('STEP A: Planning current -> READY')
        trajectory = node.plan_to(state, READY)
        if trajectory is None:
            node.get_logger().error('READY planning failed. STOP.')
            return

        node.get_logger().info('Executing READY motion...')
        if not node.execute_arm(trajectory):
            node.get_logger().error('READY motion failed. STOP.')
            return

        # 2. Ready姿勢から把持姿勢へ
        state = node.wait_for_state()
        if state is None:
            node.get_logger().error('Joint states lost. STOP.')
            return

        node.get_logger().info('STEP B: Planning READY -> GRASP')
        trajectory = node.plan_to(state, GRASP)
        if trajectory is None:
            node.get_logger().error('GRASP planning failed. STOP.')
            return

        node.get_logger().info('Executing GRASP approach...')
        if not node.execute_arm(trajectory):
            node.get_logger().error('GRASP approach failed. STOP.')
            return

        # 3. 指を閉じる
        node.get_logger().info('STEP C: Closing gripper...')
        if not node.close_hand():
            node.get_logger().error('Gripper closing failed. STOP.')
            return

        node.get_logger().info(
            'Gripper closed. Check that the gear is actually held.'
        )
        node.get_logger().info(
            'LIFT and Y motion are intentionally not started yet.'
        )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
