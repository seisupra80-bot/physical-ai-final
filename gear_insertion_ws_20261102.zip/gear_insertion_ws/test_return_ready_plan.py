import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import MotionPlanRequest, Constraints
from moveit_msgs.msg import JointConstraint


class ReturnReadyPlan(Node):
    def __init__(self):
        super().__init__('return_ready_plan')

        self.latest_joint_state = None
        self.sub = self.create_subscription(
            JointState,
            '/merged_joint_states',
            self.joint_callback,
            10
        )
        self.client = self.create_client(
            GetMotionPlan,
            '/plan_kinematic_path'
        )

    def joint_callback(self, msg):
        self.latest_joint_state = msg


def main():
    rclpy.init()
    node = ReturnReadyPlan()

    try:
        node.get_logger().info('Waiting for current joint states...')
        for _ in range(50):
            rclpy.spin_once(node, timeout_sec=0.1)
            if node.latest_joint_state is not None:
                break

        if node.latest_joint_state is None:
            node.get_logger().error('No joint states. Aborting.')
            return

        arm_names = [f'panda_joint{i}' for i in range(1, 8)]
        state_map = dict(zip(
            node.latest_joint_state.name,
            node.latest_joint_state.position
        ))

        if not all(name in state_map for name in arm_names):
            node.get_logger().error('Missing arm joints. Aborting.')
            return

        current = [state_map[name] for name in arm_names]
        ready = [0.0, -0.4, 0.0, -1.4, 0.0, 1.8, 0.785]

        node.get_logger().info('CURRENT START STATE:')
        for name, value in zip(arm_names, current):
            node.get_logger().info(f'  {name}: {value:.4f} rad')

        if not node.client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error('Planning service unavailable.')
            return

        request = GetMotionPlan.Request()
        plan = MotionPlanRequest()
        plan.group_name = 'panda_arm'
        plan.pipeline_id = 'ompl'
        plan.planner_id = 'RRTConnect'
        plan.num_planning_attempts = 5
        plan.allowed_planning_time = 10.0
        plan.max_velocity_scaling_factor = 0.05
        plan.max_acceleration_scaling_factor = 0.05

        plan.start_state.joint_state.name = arm_names
        plan.start_state.joint_state.position = current
        plan.start_state.is_diff = False

        goal = Constraints()
        for name, value in zip(arm_names, ready):
            jc = JointConstraint()
            jc.joint_name = name
            jc.position = value
            jc.tolerance_above = 0.01
            jc.tolerance_below = 0.01
            jc.weight = 1.0
            goal.joint_constraints.append(jc)

        plan.goal_constraints.append(goal)
        request.motion_plan_request = plan

        node.get_logger().info('Planning CURRENT -> READY (PLAN ONLY)...')
        future = node.client.call_async(request)
        rclpy.spin_until_future_complete(node, future, timeout_sec=20.0)

        if not future.done() or future.result() is None:
            node.get_logger().error('Planning service timed out.')
            return

        result = future.result().motion_plan_response
        node.get_logger().info(
            f'MoveIt error code: {result.error_code.val}'
        )

        if result.error_code.val != 1:
            node.get_logger().error('PLAN FAILED. Nothing was executed.')
            return

        trajectory = result.trajectory.joint_trajectory
        node.get_logger().info(
            f'PLAN SUCCESS: {len(trajectory.points)} trajectory points'
        )

        for index in sorted(set([0, len(trajectory.points)//2,
                                 len(trajectory.points)-1])):
            point = trajectory.points[index]
            node.get_logger().info(f'Point {index+1}:')
            for name, value in zip(trajectory.joint_names, point.positions):
                node.get_logger().info(f'  {name}: {value:.4f} rad')

        node.get_logger().info('PLAN ONLY. Nothing was executed.')

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
