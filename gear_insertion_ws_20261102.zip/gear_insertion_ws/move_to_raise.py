import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint


class MoveToRaise(Node):
    def __init__(self):
        super().__init__('move_to_raise')
        self.pub = self.create_publisher(
            JointTrajectory,
            '/panda_arm_controller/joint_trajectory',
            10
        )


def main():
    rclpy.init()
    node = MoveToRaise()

    try:
        joint_names = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7',
        ]

        # 現在の姿勢から、J2をさらに後方へ倒して手先を上げる
        raise_position = [
            0.0,
            -0.8,
            0.0,
            -1.4,
            0.0,
            1.8,
            0.785,
        ]

        msg = JointTrajectory()
        msg.joint_names = joint_names

        point = JointTrajectoryPoint()
        point.positions = raise_position
        point.time_from_start.sec = 4

        msg.points.append(point)

        for _ in range(20):
            if node.pub.get_subscription_count() > 0:
                break
            rclpy.spin_once(node, timeout_sec=0.1)

        node.get_logger().info(
            'Publishing raise/retreat trajectory: J2=-0.8'
        )

        node.pub.publish(msg)

        node.get_logger().info(
            'Trajectory published. Waiting 6 seconds.'
        )

        for _ in range(60):
            rclpy.spin_once(node, timeout_sec=0.1)

        node.get_logger().info(
            'Raise/retreat command finished.'
        )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
