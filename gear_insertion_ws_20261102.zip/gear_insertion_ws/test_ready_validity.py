import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetStateValidity

class ReadyValidityTest(Node):
    def __init__(self):
        super().__init__('ready_validity_test')
        self.client = self.create_client(
            GetStateValidity, '/check_state_validity')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /check_state_validity...')
        request = GetStateValidity.Request()
        request.robot_state.joint_state.name = [
            'panda_joint1', 'panda_joint2', 'panda_joint3',
            'panda_joint4', 'panda_joint5', 'panda_joint6',
            'panda_joint7'
        ]
        request.robot_state.joint_state.position = [
            0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785
        ]
        request.robot_state.is_diff = True
        request.group_name = 'panda_arm'
        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        result = future.result()
        if result is None:
            print('SERVICE FAILED')
        else:
            print('READY state valid:', result.valid)
            for contact in result.contacts:
                print('Contact:', contact.contact_body_1,
                      '-', contact.contact_body_2)
        self.destroy_node()

rclpy.init()
node = ReadyValidityTest()
rclpy.shutdown()
