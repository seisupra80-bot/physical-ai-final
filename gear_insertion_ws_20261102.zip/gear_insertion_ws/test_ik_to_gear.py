import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetPositionIK
from geometry_msgs.msg import PoseStamped


class IKTest(Node):
    def __init__(self):
        super().__init__('ik_to_gear')

        client = self.create_client(
            GetPositionIK,
            '/compute_ik'
        )

        self.get_logger().info('Waiting for /compute_ik...')

        if not client.wait_for_service(timeout_sec=5.0):
            self.get_logger().error('/compute_ik unavailable')
            return

        req = GetPositionIK.Request()

        req.ik_request.group_name = 'panda_arm'
        req.ik_request.ik_link_name = 'panda_hand'

        pose = PoseStamped()
        pose.header.frame_id = 'panda_link0'

        # 挿入ギアのハンドル付近
        pose.pose.position.x = 0.55
        pose.pose.position.y = -0.38
        pose.pose.position.z = 0.83

        # まずは一般的なPanda手先姿勢
        pose.pose.orientation.x = 0.0
        pose.pose.orientation.y = 1.0
        pose.pose.orientation.z = 0.0
        pose.pose.orientation.w = 0.0

        req.ik_request.pose_stamped = pose

        # 現在のMoveIt状態を使用
        req.ik_request.robot_state.is_diff = True

        future = client.call_async(req)
        rclpy.spin_until_future_complete(self, future)

        result = future.result()

        if result is None:
            self.get_logger().error('No IK result')
            return

        self.get_logger().info(
            f'IK error code: {result.error_code.val}'
        )

        if result.error_code.val == 1:
            self.get_logger().info('========== IK SOLUTION ==========')

            for name, pos in zip(
                result.solution.joint_state.name,
                result.solution.joint_state.position
            ):
                if name.startswith('panda_joint'):
                    self.get_logger().info(
                        f'{name}: {pos:.6f}'
                    )

            self.get_logger().info('=================================')
        else:
            self.get_logger().error('IK FAILED')


def main():
    rclpy.init()
    node = IKTest()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
