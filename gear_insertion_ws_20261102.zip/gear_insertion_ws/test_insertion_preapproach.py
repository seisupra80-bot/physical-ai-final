import rclpy
from rclpy.node import Node

from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import MotionPlanRequest
from moveit_msgs.msg import Constraints
from moveit_msgs.msg import PositionConstraint
from shape_msgs.msg import SolidPrimitive


class InsertionPreApproachPlan(Node):

    def __init__(self):
        super().__init__('insertion_preapproach_plan')

        self.latest_joint_state = None

        self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10
        )

        self.client = self.create_client(
            GetMotionPlan,
            '/plan_kinematic_path'
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg

    def wait_for_joint_state(self):
        self.get_logger().info('Waiting for /joint_states...')
        while rclpy.ok() and self.latest_joint_state is None:
            rclpy.spin_once(self, timeout_sec=0.1)

    def wait_for_service(self):
        self.get_logger().info('Waiting for planning service...')
        while rclpy.ok() and not self.client.wait_for_service(timeout_sec=1.0):
            pass

    def make_request(self):

        arm_joints = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7'
        ]

        current = {}

        for name, position in zip(
            self.latest_joint_state.name,
            self.latest_joint_state.position
        ):
            if name in arm_joints:
                current[name] = position

        req = GetMotionPlan.Request()
        mpr = MotionPlanRequest()

        mpr.group_name = 'panda_arm'
        mpr.num_planning_attempts = 10
        mpr.allowed_planning_time = 5.0
        mpr.max_velocity_scaling_factor = 0.2
        mpr.max_acceleration_scaling_factor = 0.2

        # --------------------------------------------------
        # Current joint state
        # --------------------------------------------------

        mpr.start_state.joint_state.name = arm_joints
        mpr.start_state.joint_state.position = [
            current[j] for j in arm_joints
        ]

        # --------------------------------------------------
        # Target position
        #
        # Insertion gear:
        #   (0.55, -0.35, 0.73)
        #
        # Pre-approach:
        #   (0.50, -0.25, 0.80)
        # --------------------------------------------------

        pc = PositionConstraint()

        pc.header.frame_id = 'world'
        pc.link_name = 'panda_link8'

        pc.target_point_offset.x = 0.0
        pc.target_point_offset.y = 0.0
        pc.target_point_offset.z = 0.0

        primitive = SolidPrimitive()
        primitive.type = SolidPrimitive.SPHERE
        primitive.dimensions = [0.08]

        pc.constraint_region.primitives.append(primitive)

        pc.constraint_region.primitive_poses.append(
            self.make_pose(
                0.50,
                -0.25,
                0.80
            )
        )

        pc.weight = 1.0

        constraints = Constraints()
        constraints.position_constraints.append(pc)

        mpr.goal_constraints.append(constraints)

        req.motion_plan_request = mpr

        return req

    def make_pose(self, x, y, z):
        from geometry_msgs.msg import Pose

        pose = Pose()
        pose.position.x = x
        pose.position.y = y
        pose.position.z = z
        pose.orientation.w = 1.0

        return pose

    def run(self):

        self.wait_for_joint_state()
        self.wait_for_service()

        self.get_logger().info(
            'Planning: current pose -> insertion pre-approach'
        )

        request = self.make_request()

        future = self.client.call_async(request)

        while rclpy.ok() and not future.done():
            rclpy.spin_once(self, timeout_sec=0.1)

        response = future.result()

        if response is None:
            self.get_logger().error(
                'Planning service returned no response.'
            )
            return

        result = response.motion_plan_response

        self.get_logger().info(
            f'MoveIt error code: {result.error_code.val}'
        )

        trajectory = result.trajectory.joint_trajectory

        self.get_logger().info(
            f'Trajectory points: {len(trajectory.points)}'
        )

        if len(trajectory.points) > 0:

            self.get_logger().info(
                f'First: {list(trajectory.points[0].positions)}'
            )

            self.get_logger().info(
                f'Last:  {list(trajectory.points[-1].positions)}'
            )

            self.get_logger().info(
                'INSERTION PRE-APPROACH PLAN SUCCESS'
            )

        else:
            self.get_logger().error(
                'INSERTION PRE-APPROACH PLAN FAILED'
            )


def main():
    rclpy.init()

    node = InsertionPreApproachPlan()

    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
