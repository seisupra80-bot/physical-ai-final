import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.action import ExecuteTrajectory
from moveit_msgs.msg import MotionPlanRequest, Constraints, JointConstraint
from rclpy.action import ActionClient


class ReturnReady(Node):
    def __init__(self):
        super().__init__('execute_return_ready')

        self.latest_joint_state = None
        self.create_subscription(
            JointState, '/merged_joint_states',
            self.joint_callback, 10
        )
        self.plan_client = self.create_client(
            GetMotionPlan, '/plan_kinematic_path'
        )
        self.execute_client = ActionClient(
            self, ExecuteTrajectory, '/execute_trajectory'
        )

    def joint_callback(self, msg):
        self.latest_joint_state = msg


def main():
    rclpy.init()
    node = ReturnReady()

    try:
        node.get_logger().info('Waiting for current joint states...')
        for _ in range(50):
            rclpy.spin_once(node, timeout_sec=0.1)
            if node.latest_joint_state is not None:
                break

        if node.latest_joint_state is None:
            node.get_logger().error('No joint states. Aborting.')
            return

        names = [f'panda_joint{i}' for i in range(1, 8)]
        state = dict(zip(
            node.latest_joint_state.name,
            node.latest_joint_state.position
        ))

        if not all(n in state for n in names):
            node.get_logger().error('Missing arm joints. Aborting.')
            return

        current = [state[n] for n in names]
        ready = [0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785]

        if not node.plan_client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error('Planning service unavailable.')
            return

        if not node.execute_client.wait_for_server(timeout_sec=5.0):
            node.get_logger().error('Execute action unavailable.')
            return

        request = GetMotionPlan.Request()
        plan = MotionPlanRequest()
        plan.group_name = 'panda_arm'
        plan.pipeline_id = 'ompl'
        plan.planner_id = 'RRTConnect'
        plan.num_planning_attempts = 5
        plan.allowed_planning_time = 10.0
        plan.max_velocity_scaling_factor = 0.05
        plan.max_acceleration_scaling_factor = 0.05
        plan.start_state.joint_state.name = names
        plan.start_state.joint_state.position = current
        plan.start_state.is_diff = False

        goal_constraints = Constraints()
        for name, value in zip(names, ready):
            jc = JointConstraint()
            jc.joint_name = name
            jc.position = value
            jc.tolerance_above = 0.01
            jc.tolerance_below = 0.01
            jc.weight = 1.0
            goal_constraints.joint_constraints.append(jc)

        plan.goal_constraints.append(goal_constraints)
        request.motion_plan_request = plan

        node.get_logger().info('Planning current pose -> READY...')
        future = node.plan_client.call_async(request)
        rclpy.spin_until_future_complete(node, future, timeout_sec=20.0)

        if not future.done() or future.result() is None:
            node.get_logger().error('Planning timed out. No movement.')
            return

        response = future.result().motion_plan_response
        if response.error_code.val != 1:
            node.get_logger().error(
                f'Planning failed: {response.error_code.val}. No movement.'
            )
            return

        trajectory = response.trajectory
        node.get_logger().info(
            f'Plan successful: {len(trajectory.joint_trajectory.points)} points'
        )
        node.get_logger().warn('EXECUTING READY RETURN at 5% scaling.')

        goal = ExecuteTrajectory.Goal()
        goal.trajectory = trajectory

        send_future = node.execute_client.send_goal_async(goal)
        rclpy.spin_until_future_complete(node, send_future, timeout_sec=10.0)

        if not send_future.done() or send_future.result() is None:
            node.get_logger().error('No execution response.')
            return

        goal_handle = send_future.result()
        if not goal_handle.accepted:
            node.get_logger().error('Execution goal rejected.')
            return

        node.get_logger().info('Execution accepted. Waiting for result...')
        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(
            node, result_future, timeout_sec=120.0
        )

        if not result_future.done():
            node.get_logger().error(
                'Execution wait timed out. Check robot state before retrying.'
            )
            return

        result = result_future.result().result
        node.get_logger().info(
            f'Execution error code: {result.error_code.val}'
        )
        if result.error_code.val == 1:
            node.get_logger().info('READY RETURN SUCCEEDED.')
        else:
            node.get_logger().error('READY RETURN FAILED.')

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
