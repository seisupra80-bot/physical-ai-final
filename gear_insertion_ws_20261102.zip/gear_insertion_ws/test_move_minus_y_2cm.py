import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetCartesianPath
from moveit_msgs.msg import RobotState
from geometry_msgs.msg import Pose
from sensor_msgs.msg import JointState

NAMES = [
    'panda_joint1', 'panda_joint2', 'panda_joint3',
    'panda_joint4', 'panda_joint5', 'panda_joint6',
    'panda_joint7',
    'panda_finger_joint1', 'panda_finger_joint2',
]

class TestPath(Node):
    def __init__(self):
        super().__init__('move_minus_y_2cm_plan')
        self.state = None
        self.create_subscription(
            JointState, '/merged_joint_states',
            self.callback, 10
        )
        self.client = self.create_client(
            GetCartesianPath, '/compute_cartesian_path'
        )

    def callback(self, msg):
        self.state = dict(zip(msg.name, msg.position))

    def run(self):
        import time
        deadline = time.monotonic() + 15
        while self.state is None and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.2)

        if self.state is None or not all(n in self.state for n in NAMES):
            self.get_logger().error('Joint state unavailable')
            return

        if not self.client.wait_for_service(timeout_sec=10):
            self.get_logger().error('Cartesian service unavailable')
            return

        req = GetCartesianPath.Request()
        req.header.frame_id = 'world'
        req.start_state = RobotState()
        req.start_state.joint_state.name = NAMES
        req.start_state.joint_state.position = [
            self.state[n] for n in NAMES
        ]
        req.group_name = 'panda_arm'
        req.link_name = 'panda_hand'

        pose = Pose()
        pose.position.x = 0.550
        pose.position.y = -0.472
        pose.position.z = 0.966
        pose.orientation.x = 0.575
        pose.orientation.y = 0.575
        pose.orientation.z = 0.411
        pose.orientation.w = -0.411
        req.waypoints.append(pose)

        req.max_step = 0.005
        req.jump_threshold = 0.0
        req.avoid_collisions = True
        req.max_velocity_scaling_factor = 0.1
        req.max_acceleration_scaling_factor = 0.1

        self.get_logger().info('Planning -Y 2cm only. No execution.')
        future = self.client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=60)

        if not future.done() or future.result() is None:
            self.get_logger().error('Planning timeout')
            return

        res = future.result()
        self.get_logger().info(f'Error code: {res.error_code.val}')
        self.get_logger().info(f'Cartesian fraction: {res.fraction:.4f}')
        self.get_logger().info(
            f'Trajectory points: {len(res.solution.joint_trajectory.points)}'
        )

        if res.error_code.val == 1 and res.fraction >= 0.999:
            self.get_logger().info('2CM CARTESIAN PLAN SUCCESS - NOT EXECUTED')
        else:
            self.get_logger().error('PLAN INCOMPLETE - NOT EXECUTED')

def main():
    rclpy.init()
    node = TestPath()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
