import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState

JOINT_NAMES = [
    'panda_joint1', 'panda_joint2', 'panda_joint3',
    'panda_joint4', 'panda_joint5', 'panda_joint6',
    'panda_joint7',
    'panda_finger_joint1', 'panda_finger_joint2',
]

# 現在の実測関節角度
CURRENT = [
    0.0, -0.58024379, 0.0, -1.7639, 0.0, 2.4105, 0.785,
    0.04, 0.04,
]

# 第1目標：world Y方向に -5 cm
WAYPOINT_1 = [
    0.0, -0.7052, 0.0, -1.8281, 0.0, 2.3229, 0.785,
    0.04, 0.04,
]

# 第2目標：world Z方向に +5 cm
WAYPOINT_2 = [
    0.0, -0.5985, 0.0, -1.5974, 0.0, 2.1989, 0.7851,
    0.04, 0.04,
]

# 第3目標：world Y方向に +5 cm
WAYPOINT_3 = [
    0.0, -0.4735, 0.0, -1.5122, 0.0, 2.2387, 0.7851,
    0.04, 0.04,
]


class ThreeStagePathValidity(Node):
    def __init__(self):
        super().__init__('three_stage_path_validity')
        self.client = self.create_client(
            GetStateValidity, '/check_state_validity'
        )

    def check(self, positions):
        request = GetStateValidity.Request()
        request.robot_state = RobotState()
        request.robot_state.joint_state.name = JOINT_NAMES
        request.robot_state.joint_state.position = positions
        request.robot_state.is_diff = False
        request.group_name = 'panda_arm'

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(
            self, future, timeout_sec=5.0
        )

        if not future.done() or future.result() is None:
            return None, []

        response = future.result()
        contacts = [
            f'{c.contact_body_1} <-> {c.contact_body_2}'
            for c in response.contacts
        ]
        return response.valid, contacts


def main():
    rclpy.init()
    node = ThreeStagePathValidity()

    segments = [
        ('CURRENT -> WAYPOINT 1', CURRENT, WAYPOINT_1),
        ('WAYPOINT 1 -> WAYPOINT 2', WAYPOINT_1, WAYPOINT_2),
        ('WAYPOINT 2 -> WAYPOINT 3', WAYPOINT_2, WAYPOINT_3),
    ]

    try:
        if not node.client.wait_for_service(timeout_sec=10.0):
            node.get_logger().error(
                '/check_state_validity unavailable'
            )
            return

        invalid_count = 0
        error_count = 0
        steps = 30

        for name, start, end in segments:
            node.get_logger().info(f'Checking: {name}')

            for i in range(steps + 1):
                # 区間の接続点を重複検査しない
                if i == 0 and invalid_count + error_count > 0:
                    pass

                t = i / steps
                positions = [
                    a + t * (b - a)
                    for a, b in zip(start, end)
                ]

                valid, contacts = node.check(positions)

                if valid is None:
                    error_count += 1
                    node.get_logger().error(
                        f'{name} {i}/{steps}: NO RESPONSE'
                    )
                elif valid:
                    node.get_logger().info(
                        f'{name} {i}/{steps}: VALID'
                    )
                else:
                    invalid_count += 1
                    node.get_logger().error(
                        f'{name} {i}/{steps}: INVALID'
                    )
                    for contact in contacts[:5]:
                        node.get_logger().error(
                            f'  Contact: {contact}'
                        )

        node.get_logger().info(
            f'Path check finished: INVALID={invalid_count}, '
            f'NO_RESPONSE={error_count}, TOTAL=93'
        )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
