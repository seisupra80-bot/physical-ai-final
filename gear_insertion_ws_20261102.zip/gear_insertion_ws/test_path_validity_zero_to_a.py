import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState
from sensor_msgs.msg import JointState


ARM_NAMES = [
    'panda_joint1',
    'panda_joint2',
    'panda_joint3',
    'panda_joint4',
    'panda_joint5',
    'panda_joint6',
    'panda_joint7',
]

START = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

GOAL_A = [
    0.0,
    -0.3,
    0.0,
    -2.2,
    0.0,
    1.5,
    0.785,
]


class PathValidityChecker(Node):

    def __init__(self):
        super().__init__('path_validity_zero_to_a')

        self.latest_joint_state = None

        self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10,
        )

        self.client = self.create_client(
            GetStateValidity,
            '/check_state_validity'
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg


def interpolate(start, goal, t):
    return [
        s + (g - s) * t
        for s, g in zip(start, goal)
    ]


def main():

    rclpy.init()

    node = PathValidityChecker()

    node.get_logger().info(
        'Waiting for /joint_states...'
    )

    while rclpy.ok() and node.latest_joint_state is None:
        rclpy.spin_once(node, timeout_sec=0.1)

    node.get_logger().info(
        'Waiting for /check_state_validity...'
    )

    while rclpy.ok() and not node.client.wait_for_service(
        timeout_sec=1.0
    ):
        pass

    node.get_logger().info(
        'Checking interpolated path: ZERO -> A'
    )

    first_valid = None
    last_invalid = None

    steps = 200

    for i in range(steps + 1):

        t = i / steps

        positions = interpolate(
            START,
            GOAL_A,
            t
        )

        robot_state = RobotState()

        robot_state.joint_state.name = ARM_NAMES
        robot_state.joint_state.position = positions

        request = GetStateValidity.Request()

        request.robot_state = robot_state
        request.group_name = 'panda_arm'

        future = node.client.call_async(request)

        while rclpy.ok() and not future.done():
            rclpy.spin_once(node, timeout_sec=0.05)

        if not future.done():
            node.get_logger().error(
                f't={t:.2f}: request timeout'
            )
            continue

        response = future.result()

        if response is None:
            node.get_logger().error(
                f't={t:.2f}: no response'
            )
            continue

        if response.valid:

            node.get_logger().info(
                f't={t:.2f}: VALID'
            )

            if first_valid is None:
                first_valid = t

        else:

            last_invalid = t

            if i % 5 == 0:
                node.get_logger().warn(
                    f't={t:.2f}: INVALID'
                )

    node.get_logger().info(
        '========================================'
    )

    node.get_logger().info(
        f'Last INVALID t = {last_invalid}'
    )

    node.get_logger().info(
        f'First VALID t = {first_valid}'
    )

    node.get_logger().info(
        'No motion commands were sent.'
    )

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
