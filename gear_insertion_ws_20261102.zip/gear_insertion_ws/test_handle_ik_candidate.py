import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetPositionIK
from sensor_msgs.msg import JointState
from geometry_msgs.msg import PoseStamped


class HandleIKCandidate(Node):
    def __init__(self):
        super().__init__('handle_ik_candidate')
        self.client = self.create_client(GetPositionIK, '/compute_ik')

    def run_test(self):
        if not self.client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error('/compute_ik unavailable')
            return

        req = GetPositionIK.Request()
        ik = req.ik_request

        ik.group_name = 'panda_arm'
        ik.ik_link_name = 'panda_hand'
        ik.pose_stamped = PoseStamped()
        ik.pose_stamped.header.frame_id = 'world'
        ik.pose_stamped.header.stamp = self.get_clock().now().to_msg()

        ik.pose_stamped.pose.position.x = 0.5500
        ik.pose_stamped.pose.position.y = -0.450
        ik.pose_stamped.pose.position.z = 0.961

        ik.pose_stamped.pose.orientation.x = 0.5835
        ik.pose_stamped.pose.orientation.y = 0.5837
        ik.pose_stamped.pose.orientation.z = 0.3993
        ik.pose_stamped.pose.orientation.w = -0.3992

        ik.robot_state.joint_state = JointState()
        ik.robot_state.joint_state.name = [
            'panda_joint1', 'panda_joint2', 'panda_joint3',
            'panda_joint4', 'panda_joint5', 'panda_joint6',
            'panda_joint7'
        ]
        ik.robot_state.joint_state.position = [
            0.0, -0.5985, 0.0, -1.5974, 0.0, 2.1989, 0.7851
        ]

        ik.timeout.sec = 3
        ik.avoid_collisions = False

        self.get_logger().info(
            'IK ONLY: horizontal position (0.5500, -0.4500, 0.9610)'
        )
        self.get_logger().info(
            'Target quaternion: (0.5835, 0.5837, 0.3993, -0.3992)'
        )
        self.get_logger().info('NO TRAJECTORY EXECUTION')

        future = self.client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)

        if not future.done():
            self.get_logger().error('IK request timed out')
            return

        result = future.result()
        if result is None:
            self.get_logger().error('No IK response')
            return

        code = result.error_code.val
        self.get_logger().info(f'IK error code: {code}')

        if code == 1:
            self.get_logger().info('IK SUCCESS')
            js = result.solution.joint_state
            for name, pos in zip(js.name, js.position):
                if name.startswith('panda_joint'):
                    self.get_logger().info(f'{name}: {pos:.4f} rad')
        else:
            self.get_logger().error(
                'IK FAILED: target pose was not solved'
            )


def main():
    rclpy.init()
    node = HandleIKCandidate()
    try:
        node.run_test()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
