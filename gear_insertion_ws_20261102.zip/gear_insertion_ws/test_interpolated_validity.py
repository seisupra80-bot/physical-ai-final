import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState
from sensor_msgs.msg import JointState

JOINTS = [
    'panda_joint1', 'panda_joint2', 'panda_joint3',
    'panda_joint4', 'panda_joint5', 'panda_joint6',
    'panda_joint7'
]

READY = [0.0, -0.4, 0.0, -1.4, 0.0, 1.8, 0.785]


class InterpolatedValidityTest(Node):
    def __init__(self):
        super().__init__('interpolated_validity_test')
        self.latest = None
        self.create_subscription(
            JointState, '/merged_joint_states', self.state_callback, 10
        )
        self.client = self.create_client(
            GetStateValidity, '/check_state_validity'
        )

    def state_callback(self, msg):
        self.latest = msg


def main():
    rclpy.init()
    node = InterpolatedValidityTest()

    try:
        node.get_logger().info('Waiting for /merged_joint_states...')
        for _ in range(100):
            rclpy.spin_once(node, timeout_sec=0.1)
            if node.latest is not None:
                break

        if node.latest is None:
            print('ERROR: No joint state received.')
            return

        state_map = dict(zip(node.latest.name, node.latest.position))
        if any(name not in state_map for name in JOINTS):
            print('ERROR: One or more Panda arm joints are missing.')
            return

        start = [state_map[name] for name in JOINTS]

        if not node.client.wait_for_service(timeout_sec=5.0):
            print('ERROR: /check_state_validity unavailable.')
            return

        print('Checking 21 interpolated states. No motion commands will be sent.')

        all_valid = True
        for step in range(101):
            alpha = step / 100.0
            positions = [
                a + alpha * (b - a) for a, b in zip(start, READY)
            ]

            request = GetStateValidity.Request()
            request.robot_state = RobotState()
            request.robot_state.joint_state = JointState()
            request.robot_state.joint_state.name = JOINTS
            request.robot_state.joint_state.position = positions
            request.robot_state.is_diff = True
            request.group_name = 'panda_arm'

            future = node.client.call_async(request)
            while rclpy.ok() and not future.done():
                rclpy.spin_once(node, timeout_sec=0.1)

            result = future.result()
            if result is None:
                print(f'alpha={alpha:.2f}: SERVICE ERROR')
                all_valid = False
                continue

            status = 'VALID' if result.valid else 'COLLISION'
            print(f'alpha={alpha:.2f}: {status}')
            if not result.valid:
                all_valid = False
                for contact in result.contacts:
                    print('  Contact:', contact.contact_body_1,
                          '-', contact.contact_body_2)

        print('RESULT:', 'ALL VALID' if all_valid else 'COLLISIONS FOUND')

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
