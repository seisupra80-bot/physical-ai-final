#!/usr/bin/env python3
import sys
import rclpy

from rclpy.node import Node
from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import MotionPlanRequest
from moveit_msgs.msg import Constraints, PositionConstraint
from moveit_msgs.msg import BoundingVolume
from geometry_msgs.msg import Pose, Point
from shape_msgs.msg import SolidPrimitive


class PlanGearApproach(Node):
    def __init__(self):
        super().__init__('plan_gear_approach')
        self.client = self.create_client(
            GetMotionPlan, '/plan_kinematic_path'
        )

    def plan(self):
        if not self.client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error('Planning service not available')
            return

        req = GetMotionPlan.Request()
        mpr = MotionPlanRequest()
        mpr.group_name = 'panda_arm'
        mpr.num_planning_attempts = 5
        mpr.allowed_planning_time = 5.0
        mpr.max_velocity_scaling_factor = 0.1
        mpr.max_acceleration_scaling_factor = 0.1

        constraints = Constraints()
        pc = PositionConstraint()
        pc.header.frame_id = 'world'
        pc.link_name = 'panda_link8'
        pc.weight = 1.0

        region = BoundingVolume()
        sphere = SolidPrimitive()
        sphere.type = SolidPrimitive.SPHERE
        sphere.dimensions = [0.03]
        region.primitives.append(sphere)

        center = Pose()
        center.position.x = 0.55
        center.position.y = -0.30
        center.position.z = 0.80
        center.orientation.w = 1.0
        region.primitive_poses.append(center)

        pc.constraint_region = region
        constraints.position_constraints.append(pc)
        mpr.goal_constraints.append(constraints)

        mpr.start_state.is_diff = True
        req.motion_plan_request = mpr
        future = self.client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=15.0)

        if not future.done() or future.result() is None:
            self.get_logger().error('Planning request timed out')
            return

        result = future.result().motion_plan_response
        self.get_logger().info(
            f'Planning error code: {result.error_code.val}'
        )
        if result.error_code.val == 1:
            self.get_logger().info(
                f'Plan found: {len(result.trajectory.joint_trajectory.points)} points'
            )
            self.get_logger().info(
                'Planning only; robot has NOT been commanded to move.'
            )


def main():
    rclpy.init()
    node = PlanGearApproach()
    node.plan()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
