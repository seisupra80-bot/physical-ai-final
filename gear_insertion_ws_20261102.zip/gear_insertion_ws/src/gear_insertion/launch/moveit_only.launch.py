import os

from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
from moveit_configs_utils import MoveItConfigsBuilder


def generate_launch_description():
    moveit_config = (
        MoveItConfigsBuilder(
            "moveit_resources_panda",
            package_name="moveit_resources_panda_moveit_config",
        )
        .robot_description(
            file_path="config/panda.urdf.xacro"
        )
        .robot_description_semantic(
            file_path=os.path.expanduser(
		"~/gear_insertion_ws/src/gear_insertion/config/panda.srdf"
	    )
        )
        .planning_pipelines(
            pipelines=["ompl"]
        )
        .to_moveit_configs()
    )

    return LaunchDescription([
        Node(
            package="moveit_ros_move_group",
            executable="move_group",
            name="move_group",
            remappings=[("/joint_states", "/merged_joint_states")],
            output="screen",

            parameters=[
                moveit_config.to_dict(),
                {"use_sim_time": True},
            ],
        ),
    ])
