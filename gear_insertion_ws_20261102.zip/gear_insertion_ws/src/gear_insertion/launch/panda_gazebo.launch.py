import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.actions import LogInfo
from launch.event_handlers import OnProcessExit
from launch.actions import RegisterEventHandler
from launch.event_handlers import OnProcessStart
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command
from launch_ros.actions import Node


def generate_launch_description():

    package_name = 'gear_insertion'

    package_share = get_package_share_directory(package_name)

    # ---------------------------------------------------------
    # World
    # ---------------------------------------------------------

    world_file = os.path.join(
        package_share,
        'worlds',
        'panda_world.sdf'
    )

    # ---------------------------------------------------------
    # Panda Xacro
    # ---------------------------------------------------------

    urdf_file = os.path.join(
        package_share,
        'urdf',
        'panda_gazebo.urdf.xacro'
    )

    # ---------------------------------------------------------
    # Gazebo Harmonic
    # ---------------------------------------------------------

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('ros_gz_sim'),
                'launch',
                'gz_sim.launch.py'
            )
        ),
        launch_arguments={
            'gz_args': ['-r ', world_file]
        }.items()
    )

    # ---------------------------------------------------------
    # Gazebo clock bridge: Gazebo -> ROS 2
    # ---------------------------------------------------------

    clock_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'
        ],
        output='screen'
    )

    # ---------------------------------------------------------
    # robot_description
    # ---------------------------------------------------------

    robot_description = {
        'robot_description': Command([
            'xacro ',
            urdf_file
        ])
    }

    # ---------------------------------------------------------
    # Robot State Publisher
    # ---------------------------------------------------------

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[
            robot_description,
            {'use_sim_time': True}
        ],
        remappings=[
            ('/joint_states', '/merged_joint_states')
        ]
    )

    # ---------------------------------------------------------
    # Spawn Panda into Gazebo
    # ---------------------------------------------------------

    spawn_robot = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-topic',
            'robot_description',
            '-name',
            'panda',
	    '-x', '0.0',
            '-y', '0.0',
            '-z', '0.0',
            '-Y', '0.0',
            '-allow_renaming',
            'true'
        ],
        output='screen'
    )



    # ---------------------------------------------------------
    # Controllers
    # ---------------------------------------------------------
    # ---------------------------------------------------------
    # Controllers - start sequentially after robot spawn
    # ---------------------------------------------------------

    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=[
            'joint_state_broadcaster',
            '--controller-manager',
            '/controller_manager',
            '--controller-manager-timeout',
            '60',
            '--switch-timeout',
            '60'
        ],
        output='screen'
    )

    panda_arm_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=[
            'panda_arm_controller',
            '--controller-manager',
            '/controller_manager',
            '--controller-manager-timeout',
            '60',
            '--switch-timeout',
            '60'
        ],
        output='screen'
    )

    # ---------------------------------------------------------
    # MoveIt launch
    # ---------------------------------------------------------

    moveit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                package_share,
                'launch',
                'moveit_only.launch.py'
            )
        )
    )

    start_moveit_after_controller = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=panda_arm_controller_spawner,
            on_exit=lambda event, context: (
                [moveit_launch]
                if event.returncode == 0
                else [
                    LogInfo(
                        msg='panda_arm_controller failed. '
                            'MoveIt will not start.'
                    )
                ]
            )
        )
    )


    start_joint_state_broadcaster = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=spawn_robot,
            on_exit=lambda event, context: (
                [joint_state_broadcaster_spawner]
                if event.returncode == 0
                else [
                    LogInfo(
                        msg='Panda spawn failed. Controllers will not start.'
                    )
                ]
            )
        )
    )

    start_panda_arm_controller = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=joint_state_broadcaster_spawner,
            on_exit=lambda event, context: (
                [panda_arm_controller_spawner]
                if event.returncode == 0
                else [
                    LogInfo(
                        msg='joint_state_broadcaster failed. '
                            'panda_arm_controller will not start.'
                    )
                ]
            )
        )
    )

    # ---------------------------------------------------------
    # Launch
    # ---------------------------------------------------------

    return LaunchDescription([

        gazebo,

        clock_bridge,

        robot_state_publisher,

        spawn_robot,


        start_joint_state_broadcaster,

        start_panda_arm_controller,

        start_moveit_after_controller,

    ])
