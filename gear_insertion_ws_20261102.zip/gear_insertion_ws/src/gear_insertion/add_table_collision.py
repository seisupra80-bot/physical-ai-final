#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

from moveit_msgs.msg import CollisionObject
from shape_msgs.msg import SolidPrimitive
from geometry_msgs.msg import Pose
from moveit_msgs.srv import ApplyPlanningScene
from moveit_msgs.msg import PlanningScene


class AddTableCollision(Node):

    def __init__(self):
        super().__init__('add_table_collision')
        self.client = self.create_client(
            ApplyPlanningScene, '/apply_planning_scene'
        )

    def run(self):
        if not self.client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error(
                '/apply_planning_scene が見つかりません'
            )
            return

        table = CollisionObject()
        table.header.frame_id = 'world'
        table.id = 'gear_table'

        box = SolidPrimitive()
        box.type = SolidPrimitive.BOX
        box.dimensions = [1.6, 1.2, 0.7]

        pose = Pose()
        pose.position.x = 0.55
        pose.position.y = 0.0
        pose.position.z = 0.35
        pose.orientation.w = 1.0

        table.primitives.append(box)
        table.primitive_poses.append(pose)
        table.operation = CollisionObject.ADD

        scene = PlanningScene()
        scene.world.collision_objects.append(table)
        scene.is_diff = True

        request = ApplyPlanningScene.Request()
        request.scene = scene

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(
            self, future, timeout_sec=10.0
        )

        if not future.done() or future.result() is None:
            self.get_logger().error('登録要求が完了しませんでした')
            return

        if future.result().success:
            self.get_logger().info(
                'gear_table を MoveIt に登録しました'
            )
        else:
            self.get_logger().error(
                'MoveItへの登録に失敗しました'
            )


def main():
    rclpy.init()
    node = AddTableCollision()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
