#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState
from sensor_msgs.msg import JointState


class CheckCurrentState(Node):
    def __init__(self):
        super().__init__('check_current_state')
        self.latest_joint_state = None

        self.create_subscription(
            JointState, '/joint_states',
            self.joint_callback, 10
        )
        self.client = self.create_client(
            GetStateValidity, '/check_state_validity'
        )

    def joint_callback(self, msg):
        self.latest_joint_state = msg

    def run(self):
        if not self.client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error('Service unavailable')
            return

        deadline = self.get_clock().now().nanoseconds + 5_000_000_000
        while self.latest_joint_state is None:
            rclpy.spin_once(self, timeout_sec=0.1)
            if self.get_clock().now().nanoseconds > deadline:
                self.get_logger().error('No joint states received')
                return

        state = RobotState()
        state.joint_state = self.latest_joint_state

        req = GetStateValidity.Request()
        req.robot_state = state
        req.group_name = 'panda_arm'

        future = self.client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=10.0)

        if not future.done() or future.result() is None:
            self.get_logger().error('Validity check failed')
            return

        result = future.result()
        self.get_logger().info(f'is_valid = {result.valid}')
        for contact in result.contacts:
            self.get_logger().info(
                f'Collision: {contact.contact_body_1} / '
                f'{contact.contact_body_2}'
            )


def main():
    rclpy.init()
    node = CheckCurrentState()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
