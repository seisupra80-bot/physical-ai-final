# ai_estimator.py

import torch
import torch.nn as nn


class GearPositionNet(nn.Module):

    def __init__(self):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(6, 64),
            nn.ReLU(),

            nn.Linear(64, 64),
            nn.ReLU(),

            nn.Linear(64, 32),
            nn.ReLU(),

            nn.Linear(32, 3)
        )

    def forward(self, x):
        return self.net(x)


def estimate_position(left_gear, right_gear):

    model = GearPositionNet()

    # 今回はデモ用。
    # 学習済みモデルがあればロードする。
    #
    # model.load_state_dict(
    #     torch.load("gear_position.pt")
    # )

    x = torch.tensor(
        left_gear + right_gear,
        dtype=torch.float32
    ).unsqueeze(0)

    with torch.no_grad():
        y = model(x)

    return y.squeeze(0).numpy()