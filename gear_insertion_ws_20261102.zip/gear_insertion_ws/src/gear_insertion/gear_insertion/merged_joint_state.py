import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


class MergedJointState(Node):
    def __init__(self):
        super().__init__('merged_joint_state')

        self.arm_state = {}
        self.finger_state = {}

        self.create_subscription(
            JointState,
            '/joint_states',
            self.arm_callback,
            10
        )

        self.create_subscription(
            JointState,
            '/finger_joint_states',
            self.finger_callback,
            10
        )

        self.publisher = self.create_publisher(
            JointState,
            '/merged_joint_states',
            10
        )

        self.timer = self.create_timer(
            0.02,
            self.publish_state
        )

    def arm_callback(self, msg):
        for i, name in enumerate(msg.name):
            if i < len(msg.position):
                self.arm_state[name] = msg.position[i]

    def finger_callback(self, msg):
        for i, name in enumerate(msg.name):
            if i < len(msg.position):
                self.finger_state[name] = msg.position[i]

    def publish_state(self):
        if len(self.arm_state) < 7:
            return

        if len(self.finger_state) < 2:
            return

        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()

        names = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7',
            'panda_finger_joint1',
            'panda_finger_joint2'
        ]

        msg.name = names
        msg.position = [
            self.arm_state[name]
            for name in names[:7]
        ] + [
            self.finger_state['panda_finger_joint1'],
            self.finger_state['panda_finger_joint2']
        ]

        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)

    node = MergedJointState()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
