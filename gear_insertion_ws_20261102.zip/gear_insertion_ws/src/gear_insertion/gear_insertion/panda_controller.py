import rclpy
from rclpy.node import Node

from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint


class PandaController(Node):

    def __init__(self):
        super().__init__('panda_controller')

        # Panda 7軸の関節名
        self.joint_names = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7'
        ]

        # JointTrajectoryを送信するPublisher
        self.publisher = self.create_publisher(
            JointTrajectory,
            '/panda_arm_controller/joint_trajectory',
            10
        )

        # 起動して2秒後に動作
        self.timer = self.create_timer(
            2.0,
            self.move_panda
        )

        self.executed = False

        self.get_logger().info(
            'Panda controller started.'
        )

    def move_panda(self):

        # 一度だけ実行
        if self.executed:
            return

        self.executed = True

        trajectory = JointTrajectory()

        trajectory.joint_names = self.joint_names

        point = JointTrajectoryPoint()

        # Pandaを見やすい姿勢へ移動
        point.positions = [
            0.4,    # joint1
            0.2,    # joint2
            0.0,    # joint3
            -1.8,   # joint4
            0.0,    # joint5
            1.5,    # joint6
            0.4     # joint7
        ]

        # 5秒かけて移動
        point.time_from_start.sec = 5

        trajectory.points.append(point)

        self.publisher.publish(trajectory)

        self.get_logger().info(
            'Panda movement command sent.'
        )


def main(args=None):

    rclpy.init(args=args)

    node = PandaController()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
