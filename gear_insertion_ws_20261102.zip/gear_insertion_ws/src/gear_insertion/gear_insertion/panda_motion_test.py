import rclpy

from rclpy.node import Node

from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint


class PandaMotionTest(Node):

    def __init__(self):

        super().__init__('panda_motion_test')

        self.publisher = self.create_publisher(
            JointTrajectory,
            '/panda_arm_controller/joint_trajectory',
            10
        )

        self.timer = self.create_timer(
            3.0,
            self.send_trajectory
        )

        self.sent = False

        self.get_logger().info(
            'Panda motion test node started.'
        )

    def send_trajectory(self):

        if self.sent:
            return

        msg = JointTrajectory()

        msg.joint_names = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7',
        ]

        point = JointTrajectoryPoint()

        point.positions = [
            0.0,
            -0.5,
            0.0,
            -1.8,
            0.0,
            1.2,
            0.0,
        ]

        point.time_from_start.sec = 5

        msg.points.append(point)

        self.publisher.publish(msg)

        self.get_logger().info(
            'Trajectory command sent.'
        )

        self.sent = True


def main(args=None):

    rclpy.init(args=args)

    node = PandaMotionTest()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()