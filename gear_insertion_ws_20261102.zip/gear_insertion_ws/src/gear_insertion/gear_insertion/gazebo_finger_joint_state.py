import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

from gz.transport13 import Node as GzNode
import gz.msgs.model_pb2 as model_pb2


class GazeboFingerJointState(Node):
    def __init__(self):
        super().__init__('gazebo_finger_joint_state')

        self.publisher = self.create_publisher(
            JointState,
            '/finger_joint_states',
            10
        )

        self.gz_node = GzNode()

        self.gz_subscription = self.gz_node.subscribe(
            model_pb2.Model,
            '/world/panda_world/model/panda/joint_state',
            self.gz_callback
        )

        self.latest = {}

        self.timer = self.create_timer(0.02, self.publish_state)

    def gz_callback(self, msg):
        for joint in msg.joint:
            if joint.name in (
                'panda_finger_joint1',
                'panda_finger_joint2'
            ):
                self.latest[joint.name] = joint.axis1.position

    def publish_state(self):
        if len(self.latest) < 2:
            return

        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()

        msg.name = [
            'panda_finger_joint1',
            'panda_finger_joint2'
        ]

        msg.position = [
            self.latest['panda_finger_joint1'],
            self.latest['panda_finger_joint2']
        ]

        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = GazeboFingerJointState()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
