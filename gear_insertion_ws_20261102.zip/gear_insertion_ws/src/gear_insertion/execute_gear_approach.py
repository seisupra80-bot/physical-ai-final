#!/usr/bin/env python3
import rclpy

from rclpy.node import Node
from rclpy.action import ActionClient

from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import MotionPlanRequest, Constraints
from moveit_msgs.msg import PositionConstraint, BoundingVolume
from geometry_msgs.msg import Pose
from shape_msgs.msg import SolidPrimitive
from control_msgs.action import FollowJointTrajectory


class ExecuteGearApproach(Node):
    def __init__(self):
        super().__init__('execute_gear_approach')

        self.plan_client = self.create_client(
            GetMotionPlan, '/plan_kinematic_path'
        )
        self.execute_client = ActionClient(
            self,
            FollowJointTrajectory,
            '/panda_arm_controller/follow_joint_trajectory'
        )

    def run(self):
        self.get_logger().info('Waiting for MoveIt and trajectory controller...')

        if not self.plan_client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error('MoveIt planning service unavailable')
            return

        if not self.execute_client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error('Trajectory action unavailable')
            return

        req = GetMotionPlan.Request()
        mpr = MotionPlanRequest()
        mpr.group_name = 'panda_arm'
        mpr.num_planning_attempts = 5
        mpr.allowed_planning_time = 5.0
        mpr.max_velocity_scaling_factor = 0.05
        mpr.max_acceleration_scaling_factor = 0.05
        mpr.start_state.is_diff = True

        pc = PositionConstraint()
        pc.header.frame_id = 'world'
        pc.link_name = 'panda_link8'
        pc.weight = 1.0

        region = BoundingVolume()
        sphere = SolidPrimitive()
        sphere.type = SolidPrimitive.SPHERE
        sphere.dimensions = [0.03]
        region.primitives.append(sphere)

        center = Pose()
        center.position.x = 0.55
        center.position.y = -0.30
        center.position.z = 0.80
        center.orientation.w = 1.0
        region.primitive_poses.append(center)

        pc.constraint_region = region
        constraints = Constraints()
        constraints.position_constraints.append(pc)
        mpr.goal_constraints.append(constraints)
        req.motion_plan_request = mpr

        self.get_logger().info('Planning trajectory...')
        future = self.plan_client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=20.0)

        if not future.done() or future.result() is None:
            self.get_logger().error('Planning request failed or timed out')
            return

        response = future.result().motion_plan_response
        if response.error_code.val != 1:
            self.get_logger().error(
                f'Planning failed: {response.error_code.val}'
            )
            return

        trajectory = response.trajectory.joint_trajectory
        if not trajectory.points:
            self.get_logger().error('Trajectory is empty')
            return

        self.get_logger().info(
            f'Plan found: {len(trajectory.points)} points'
        )
        self.get_logger().warn(
            'Starting execution in 5 seconds. Keep the simulation visible.'
        )

        # Give the user time to stop this script with Ctrl+C if needed.
        import time
        time.sleep(5)

        goal = FollowJointTrajectory.Goal()
        goal.trajectory = trajectory

        send_future = self.execute_client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, send_future, timeout_sec=10.0)

        if not send_future.done() or send_future.result() is None:
            self.get_logger().error('Could not send trajectory goal')
            return

        goal_handle = send_future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Trajectory goal rejected')
            return

        self.get_logger().info('Trajectory accepted; waiting for result...')
        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(
            self, result_future, timeout_sec=60.0
        )

        if not result_future.done() or result_future.result() is None:
            self.get_logger().error(
                'No result received within 60 seconds; check robot state'
            )
            return

        result = result_future.result().result
        self.get_logger().info(
            f'Trajectory result error_code: {result.error_code}'
        )
        self.get_logger().info(result.error_string)


def main():
    rclpy.init()
    node = ExecuteGearApproach()
    try:
        node.run()
    except KeyboardInterrupt:
        node.get_logger().warn('Interrupted by user')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
