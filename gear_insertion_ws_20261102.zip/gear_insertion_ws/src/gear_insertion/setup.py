from setuptools import setup
import os
from glob import glob


package_name = 'gear_insertion'


setup(
    name=package_name,

    version='0.0.1',

    packages=[package_name],

    data_files=[

        (
            'share/ament_index/resource_index/packages',
            ['resource/' + package_name]
        ),

        (
            'share/' + package_name,
            ['package.xml']
        ),

        (
            os.path.join('share', package_name, 'launch'),
            glob('launch/*.py')
        ),

        (
            os.path.join('share', package_name, 'config'),
            [f for f in glob('config/*.yaml') if '.bak' not in os.path.basename(f)]
        ),

        (
            os.path.join('share', package_name, 'urdf'),
            [f for f in [f for f in glob('urdf/*') if '.bak' not in os.path.basename(f)] if '.bak' not in os.path.basename(f)]
        ),

        (
            os.path.join('share', package_name, 'worlds'),
            [f for f in glob('worlds/*') if '.bak' not in os.path.basename(f)]
        ),

    ],

    install_requires=['setuptools'],

    zip_safe=True,

    maintainer='user',

    maintainer_email='user@example.com',

    description='7DOF Panda robot gear insertion simulation',

    license='Apache-2.0',

    entry_points={
        'console_scripts': [
            'panda_controller = gear_insertion.panda_controller:main',
            'gazebo_finger_joint_state = gear_insertion.gazebo_finger_joint_state:main',
            'merged_joint_state = gear_insertion.merged_joint_state:main',
        ],
    },
)