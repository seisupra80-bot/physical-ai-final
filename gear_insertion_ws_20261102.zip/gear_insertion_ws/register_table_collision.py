import rclpy
from rclpy.node import Node

from moveit_msgs.srv import ApplyPlanningScene
from moveit_msgs.msg import PlanningScene, CollisionObject
from shape_msgs.msg import SolidPrimitive
from geometry_msgs.msg import Pose


class RegisterScene(Node):
    def __init__(self):
        super().__init__('register_gear_scene')

        self.client = self.create_client(
            ApplyPlanningScene,
            '/apply_planning_scene'
        )

    def add_box(self, scene, object_id, position, dimensions):
        obj = CollisionObject()
        obj.header.frame_id = 'panda_link0'
        obj.id = object_id
        obj.operation = CollisionObject.ADD

        shape = SolidPrimitive()
        shape.type = SolidPrimitive.BOX
        shape.dimensions = dimensions

        pose = Pose()
        pose.position.x = position[0]
        pose.position.y = position[1]
        pose.position.z = position[2]
        pose.orientation.w = 1.0

        obj.primitives.append(shape)
        obj.primitive_poses.append(pose)
        scene.world.collision_objects.append(obj)

    def add_cylinder(self, scene, object_id, position, radius, length):
        obj = CollisionObject()
        obj.header.frame_id = 'panda_link0'
        obj.id = object_id
        obj.operation = CollisionObject.ADD

        shape = SolidPrimitive()
        shape.type = SolidPrimitive.CYLINDER
        shape.dimensions = [length, radius]

        pose = Pose()
        pose.position.x = position[0]
        pose.position.y = position[1]
        pose.position.z = position[2]
        pose.orientation.w = 1.0

        obj.primitives.append(shape)
        obj.primitive_poses.append(pose)
        scene.world.collision_objects.append(obj)

    def run(self):
        self.get_logger().info('Waiting for MoveIt service...')

        if not self.client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error(
                'apply_planning_scene unavailable'
            )
            return

        scene = PlanningScene()
        scene.is_diff = True

        # Table: SDF size 1.6 x 1.2 x 0.05 m
        self.add_box(
            scene, 'gear_table',
            (0.80, 0.00, 0.675),
            [1.2, 1.6, 0.05]
        )

        # Fixed gears: conservative cylindrical envelopes
        self.add_cylinder(
            scene, 'fixed_gear_1',
            (0.80, 0.45, 0.725),
            0.35, 0.06
        )

        self.add_cylinder(
            scene, 'fixed_gear_2',
            (0.80, -0.45, 0.725),
            0.35, 0.06
        )

        # Insertion gear body and teeth envelope
        self.add_cylinder(
            scene, 'insertion_gear_body',
            (0.45, 0.00, 0.725),
            0.25, 0.06
        )

        # Vertical grasping handle
        self.add_cylinder(
            scene, 'insertion_gear_handle',
            (0.45, 0.00, 0.845),
            0.015, 0.18
        )

        request = ApplyPlanningScene.Request()
        request.scene = scene

        self.get_logger().info(
            'Registering table and four gear collision objects...'
        )

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(
            self, future, timeout_sec=10.0
        )

        if future.done() and future.result() is not None:
            if future.result().success:
                self.get_logger().info(
                    'GEAR SCENE REGISTERED: 5 objects'
                )
            else:
                self.get_logger().error(
                    'Planning scene registration failed'
                )
        else:
            self.get_logger().error(
                'Planning scene service call timed out'
            )


def main():
    rclpy.init()
    node = RegisterScene()

    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
