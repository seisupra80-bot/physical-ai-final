import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


class CheckInitialJoints(Node):
    def __init__(self):
        super().__init__('check_initial_joints')
        self.received = False
        self.sub = self.create_subscription(
            JointState,
            '/merged_joint_states',
            self.callback,
            10
        )

    def callback(self, msg):
        if self.received:
            return

        self.received = True
        for name, position in zip(msg.name, msg.position):
            if name.startswith('panda_joint') and 'finger' not in name:
                self.get_logger().info(f'{name}: {position:.6f} rad')


def main():
    rclpy.init()
    node = CheckInitialJoints()

    try:
        for _ in range(100):
            if node.received:
                break
            rclpy.spin_once(node, timeout_sec=0.1)

        if not node.received:
            node.get_logger().error('No joint states received.')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
