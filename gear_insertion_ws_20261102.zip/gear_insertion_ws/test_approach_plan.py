import rclpy
from rclpy.node import Node

from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import MotionPlanRequest
from moveit_msgs.msg import Constraints
from moveit_msgs.msg import JointConstraint


class ApproachPlan(Node):

    def __init__(self):
        super().__init__('approach_plan')

        self.latest_joint_state = None

        self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10
        )

        self.client = self.create_client(
            GetMotionPlan,
            '/plan_kinematic_path'
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg

    def run(self):

        self.get_logger().info('Waiting for /joint_states...')
        while rclpy.ok() and self.latest_joint_state is None:
            rclpy.spin_once(self, timeout_sec=0.1)

        self.get_logger().info('Waiting for planning service...')
        while rclpy.ok() and not self.client.wait_for_service(timeout_sec=1.0):
            pass

        self.get_logger().info('Planning ONLY: READY -> APPROACH')

        # 現在のREADY姿勢を基準に、
        # まずは安全側の関節姿勢を試す。
        target = [
            0.0,
            -0.55,
            0.0,
            -2.10,
            0.0,
            1.45,
            0.785
        ]

        request = GetMotionPlan.Request()
        request.motion_plan_request = MotionPlanRequest()

        req = request.motion_plan_request
        req.group_name = 'panda_arm'
        req.num_planning_attempts = 5
        req.allowed_planning_time = 2.0
        req.max_velocity_scaling_factor = 0.2
        req.max_acceleration_scaling_factor = 0.2

        constraints = Constraints()

        for i, joint_name in enumerate([
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7'
        ]):
            jc = JointConstraint()
            jc.joint_name = joint_name
            jc.position = target[i]
            jc.tolerance_above = 0.05
            jc.tolerance_below = 0.05
            jc.weight = 1.0
            constraints.joint_constraints.append(jc)

        req.goal_constraints.append(constraints)

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        result = future.result()

        if result is None:
            self.get_logger().error('Planning service failed.')
            return

        self.get_logger().info(
            f'MoveIt error code: {result.motion_plan_response.error_code.val}'
        )

        traj = result.motion_plan_response.trajectory

        self.get_logger().info(
            f'Trajectory points: {len(traj.joint_trajectory.points)}'
        )

        if traj.joint_trajectory.points:
            self.get_logger().info(
                f'First: {list(traj.joint_trajectory.points[0].positions)}'
            )
            self.get_logger().info(
                f'Last:  {list(traj.joint_trajectory.points[-1].positions)}'
            )

        if result.motion_plan_response.error_code.val == 1:
            self.get_logger().info('APPROACH PLAN SUCCESS')
        else:
            self.get_logger().error('APPROACH PLAN FAILED')


def main():
    rclpy.init()
    node = ApproachPlan()
    node.run()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
