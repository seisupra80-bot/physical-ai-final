import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetPositionFK


class HandleFKTest(Node):

    def __init__(self):
        super().__init__('handle_fk_test')

        self.client = self.create_client(
            GetPositionFK,
            '/compute_fk'
        )


def main():
    rclpy.init()
    node = HandleFKTest()

    try:
        node.get_logger().info('Waiting for FK service...')

        if not node.client.wait_for_service(timeout_sec=10.0):
            node.get_logger().error('FK service unavailable.')
            return

        request = GetPositionFK.Request()

        request.header.frame_id = 'world'
        request.fk_link_names = ['panda_hand', 'panda_leftfinger', 'panda_rightfinger']

        request.robot_state.joint_state.name = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7',
            'panda_finger_joint1',
            'panda_finger_joint2',
        ]

        request.robot_state.joint_state.position = [
            0.0,
            -0.6013,
            0.0,
            -1.8860,
            0.0,
            2.4847,
            0.785,
            0.04,
            0.04,
        ]

        request.robot_state.is_diff = False

        node.get_logger().info(
            'Calculating FK for planned final joint positions.'
        )

        future = node.client.call_async(request)

        while rclpy.ok() and not future.done():
            rclpy.spin_once(node, timeout_sec=0.1)

        response = future.result()

        if response is None:
            node.get_logger().error('No FK response.')
            return

        node.get_logger().info(
            f'FK error code: {response.error_code.val}'
        )

        for pose in response.pose_stamped:
            p = pose.pose.position
            q = pose.pose.orientation

            node.get_logger().info(
                f'Frame: {pose.header.frame_id}'
            )
            node.get_logger().info(
                f'Position: x={p.x:.4f}, y={p.y:.4f}, z={p.z:.4f} m'
            )
            node.get_logger().info(
                f'Quaternion: x={q.x:.4f}, y={q.y:.4f}, '
                f'z={q.z:.4f}, w={q.w:.4f}'
            )

            import numpy as np
            from scipy.spatial.transform import Rotation

            quat = [q.x, q.y, q.z, q.w]
            R = Rotation.from_quat(quat).as_matrix()

            node.get_logger().info(
                f'Hand local X axis in world: {R[:, 0]}'
            )
            node.get_logger().info(
                f'Hand local Y axis in world: {R[:, 1]}'
            )
            node.get_logger().info(
                f'Hand local Z axis in world: {R[:, 2]}'
            )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
