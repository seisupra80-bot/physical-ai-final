import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState


ARM_NAMES = [
    'panda_joint1',
    'panda_joint2',
    'panda_joint3',
    'panda_joint4',
    'panda_joint5',
    'panda_joint6',
    'panda_joint7',
]

ESCAPE_POSE = [
    0.0,
    -0.075,
    0.0,
    -0.55,
    0.0,
    0.375,
    0.19625,
]


class EscapePoseChecker(Node):

    def __init__(self):
        super().__init__('escape_pose_validity')

        self.client = self.create_client(
            GetStateValidity,
            '/check_state_validity'
        )


def main():

    rclpy.init()

    node = EscapePoseChecker()

    node.get_logger().info(
        'Waiting for /check_state_validity...'
    )

    while rclpy.ok() and not node.client.wait_for_service(
        timeout_sec=1.0
    ):
        pass

    robot_state = RobotState()

    robot_state.joint_state.name = ARM_NAMES
    robot_state.joint_state.position = ESCAPE_POSE

    request = GetStateValidity.Request()
    request.robot_state = robot_state
    request.group_name = 'panda_arm'

    node.get_logger().info(
        'Checking ESCAPE POSE (t=0.25)...'
    )

    future = node.client.call_async(request)

    while rclpy.ok() and not future.done():
        rclpy.spin_once(node, timeout_sec=0.05)

    response = future.result()

    if response is None:
        node.get_logger().error(
            'No response from /check_state_validity'
        )
    else:
        node.get_logger().info(
            f'is_valid = {response.valid}'
        )

        node.get_logger().info(
            'ESCAPE POSE: ' +
            ('VALID' if response.valid else 'INVALID')
        )

        if not response.valid:
            for contact in response.contacts:
                node.get_logger().warn(
                    f'Collision: '
                    f'{contact.contact_body_1} <-> '
                    f'{contact.contact_body_2}'
                )

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
