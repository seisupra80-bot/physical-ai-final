import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState
from sensor_msgs.msg import JointState

JOINTS = [
    'panda_joint1',
    'panda_joint2',
    'panda_joint3',
    'panda_joint4',
    'panda_joint5',
    'panda_joint6',
    'panda_joint7'
]

POSE = [
    0.0,
    -0.8,
    0.0,
    -1.4,
    0.0,
    1.8,
    0.785
]


def main():
    rclpy.init()
    node = Node('raise_pose_validity_test')
    client = node.create_client(
        GetStateValidity,
        '/check_state_validity'
    )

    try:
        if not client.wait_for_service(timeout_sec=5.0):
            print('ERROR: /check_state_validity unavailable.')
            return

        request = GetStateValidity.Request()
        request.robot_state = RobotState()
        request.robot_state.joint_state = JointState()
        request.robot_state.joint_state.name = JOINTS
        request.robot_state.joint_state.position = POSE
        request.robot_state.is_diff = True
        request.group_name = 'panda_arm'

        future = client.call_async(request)
        rclpy.spin_until_future_complete(node, future)

        result = future.result()

        if result is None:
            print('SERVICE FAILED')
            return

        print('Raise pose valid:', result.valid)

        for contact in result.contacts:
            print(
                'Contact:',
                contact.contact_body_1,
                '-',
                contact.contact_body_2
            )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
