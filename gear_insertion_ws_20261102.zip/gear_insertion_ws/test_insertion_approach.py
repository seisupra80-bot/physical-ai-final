import rclpy
from rclpy.node import Node

from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import MotionPlanRequest
from moveit_msgs.msg import Constraints
from moveit_msgs.msg import PositionConstraint
from moveit_msgs.msg import OrientationConstraint
from geometry_msgs.msg import Pose


class InsertionApproach(Node):

    def __init__(self):
        super().__init__('insertion_approach_plan')

        self.client = self.create_client(
            GetMotionPlan,
            '/plan_kinematic_path'
        )

    def run(self):

        self.get_logger().info('Waiting for planning service...')

        while not self.client.wait_for_service(timeout_sec=1.0):
            pass

        self.get_logger().info(
            'Planning ONLY: approach position before gear insertion'
        )

        req = MotionPlanRequest()
        req.group_name = 'panda_arm'
        req.num_planning_attempts = 5
        req.allowed_planning_time = 3.0
        req.max_velocity_scaling_factor = 0.2
        req.max_acceleration_scaling_factor = 0.2

        constraints = Constraints()

        # --------------------------------------------------
        # Position target
        # --------------------------------------------------

        pc = PositionConstraint()
        pc.header.frame_id = 'world'
        pc.link_name = 'panda_link8'

        pc.target_point_offset.x = 0.0
        pc.target_point_offset.y = 0.0
        pc.target_point_offset.z = 0.0

        # 半径1 cm以内
        from shape_msgs.msg import SolidPrimitive
        primitive = SolidPrimitive()
        primitive.type = SolidPrimitive.SPHERE
        primitive.dimensions = [0.01]

        pc.constraint_region.primitives.append(primitive)

        pose = Pose()
        pose.position.x = 0.550
        pose.position.y = -0.250
        pose.position.z = 0.830

        # 現在の手先姿勢をそのまま使用
        pose.orientation.x = 0.923
        pose.orientation.y = -0.382
        pose.orientation.z = -0.046
        pose.orientation.w = 0.019

        pc.constraint_region.primitive_poses.append(pose)
        pc.weight = 1.0

        constraints.position_constraints.append(pc)

        # --------------------------------------------------
        # Orientation target
        # --------------------------------------------------

        oc = OrientationConstraint()
        oc.header.frame_id = 'world'
        oc.link_name = 'panda_link8'

        oc.orientation = pose.orientation

        oc.absolute_x_axis_tolerance = 0.10
        oc.absolute_y_axis_tolerance = 0.10
        oc.absolute_z_axis_tolerance = 0.10
        oc.weight = 1.0

        constraints.orientation_constraints.append(oc)

        req.goal_constraints.append(constraints)

        request = GetMotionPlan.Request()
        request.motion_plan_request = req

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        result = future.result()

        if result is None:
            self.get_logger().error('Planning service failed.')
            return

        code = result.motion_plan_response.error_code.val

        self.get_logger().info(f'MoveIt error code: {code}')

        trajectory = result.motion_plan_response.trajectory

        self.get_logger().info(
            f'Trajectory points: '
            f'{len(trajectory.joint_trajectory.points)}'
        )

        if trajectory.joint_trajectory.points:
            first = trajectory.joint_trajectory.points[0].positions
            last = trajectory.joint_trajectory.points[-1].positions

            self.get_logger().info(f'First: {list(first)}')
            self.get_logger().info(f'Last:  {list(last)}')

        if code == 1:
            self.get_logger().info(
                'INSERTION APPROACH PLAN SUCCESS'
            )
        else:
            self.get_logger().error(
                'INSERTION APPROACH PLAN FAILED'
            )


def main():
    rclpy.init()
    node = InsertionApproach()
    node.run()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
