import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint


class MoveToSafeStart(Node):
    def __init__(self):
        super().__init__('move_to_safe_start')

        self.pub = self.create_publisher(
            JointTrajectory,
            '/panda_arm_controller/joint_trajectory',
            10
        )


def main():
    rclpy.init()
    node = MoveToSafeStart()

    try:
        joint_names = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7',
        ]

        safe_position = [
            0.0,
            -0.4,
            0.0,
            -1.4,
            0.0,
            1.8,
            0.785,
        ]

        msg = JointTrajectory()
        msg.joint_names = joint_names

        point = JointTrajectoryPoint()
        point.positions = safe_position
        point.time_from_start.sec = 5
        msg.points.append(point)

        # Wait briefly for publisher/subscriber connection
        for _ in range(20):
            if node.pub.get_subscription_count() > 0:
                break
            rclpy.spin_once(node, timeout_sec=0.1)

        node.get_logger().info(
            'Publishing safe-start trajectory.'
        )

        node.pub.publish(msg)

        node.get_logger().info(
            'Trajectory published. Waiting 7 seconds.'
        )

        for _ in range(70):
            rclpy.spin_once(node, timeout_sec=0.1)

        node.get_logger().info(
            'Safe-start command finished.'
        )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
