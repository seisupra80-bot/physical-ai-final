import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetPositionFK
from moveit_msgs.msg import RobotState
from sensor_msgs.msg import JointState


class OrientationTest(Node):

    def __init__(self):
        super().__init__('handle_orientation_test')
        self.client = self.create_client(
            GetPositionFK, '/compute_fk'
        )

    def calculate(self, label, quaternion):
        request = GetPositionFK.Request()
        request.header.frame_id = 'world'
        request.fk_link_names = ['panda_hand']

        request.robot_state.joint_state.name = [
            f'panda_joint{i}' for i in range(1, 8)
        ]
        request.robot_state.joint_state.position = [
            -1.6802, 0.3711, 2.2544, -1.1902,
            -2.8570, 2.1153, -2.4712
        ]
        request.robot_state.is_diff = False

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        response = future.result()
        if response is None or response.error_code.val != 1:
            self.get_logger().error(f'{label}: FK failed')
            return

        pose = response.pose_stamped[0].pose
        p = pose.position

        self.get_logger().info(
            f'{label}: position=({p.x:.4f}, {p.y:.4f}, {p.z:.4f})'
        )
        self.get_logger().info(
            f'{label}: FK uses the supplied joint state; '
            f'orientation candidate={quaternion}'
        )


def main():
    rclpy.init()
    node = OrientationTest()

    try:
        if not node.client.wait_for_service(timeout_sec=10.0):
            node.get_logger().error('FK service unavailable')
            return

        candidates = [
            ('A current', (0.0, 0.0, 0.0, 1.0)),
            ('B rotate X 180', (1.0, 0.0, 0.0, 0.0)),
            ('C rotate Y 180', (0.0, 1.0, 0.0, 0.0)),
        ]

        for label, quaternion in candidates:
            node.get_logger().info(
                f'{label}: quaternion={quaternion}'
            )

        node.get_logger().info(
            'These are orientation candidates only; no motion is executed.'
        )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
