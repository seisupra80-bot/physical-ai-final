#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetPositionIK
from sensor_msgs.msg import JointState
from geometry_msgs.msg import PoseStamped

class IKTest(Node):
    def __init__(self):
        super().__init__('ik_handle_test')
        self.client = self.create_client(
            GetPositionIK, '/compute_ik'
        )

    def run_test(self):
        if not self.client.wait_for_service(timeout_sec=10.0):
            print('ERROR: /compute_ik service unavailable')
            return

        req = GetPositionIK.Request()
        req.ik_request.group_name = 'panda_arm'
        req.ik_request.ik_link_name = 'panda_hand'
        req.ik_request.pose_stamped = PoseStamped()
        req.ik_request.pose_stamped.header.frame_id = 'panda_link0'
        req.ik_request.pose_stamped.header.stamp = self.get_clock().now().to_msg()

        # 仮の目標：ギア中心の真上
        req.ik_request.pose_stamped.pose.position.x = 0.550
        req.ik_request.pose_stamped.pose.position.y = -0.380
        req.ik_request.pose_stamped.pose.position.z = 0.945

        # 現在のハンド姿勢を固定せず、まず垂直姿勢を試す
        req.ik_request.pose_stamped.pose.orientation.x = 0.946
        req.ik_request.pose_stamped.pose.orientation.y = 0.322
        req.ik_request.pose_stamped.pose.orientation.z = 0.0
        req.ik_request.pose_stamped.pose.orientation.w = 0.0

        # 現在の関節状態を明示的に指定
        req.ik_request.robot_state.joint_state.name = [
            'panda_joint1', 'panda_joint2', 'panda_joint3',
            'panda_joint4', 'panda_joint5', 'panda_joint6',
            'panda_joint7'
        ]
        req.ik_request.robot_state.joint_state.position = [
            0.0, -0.00694, -0.13058, 0.0, 0.0, 0.0, 0.0
        ]

        req.ik_request.timeout.sec = 2
        req.ik_request.avoid_collisions = False

        future = self.client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)

        if not future.done():
            print('ERROR: IK request timed out')
            return

        result = future.result()
        if result is None:
            print('ERROR: no IK response')
            return

        code = result.error_code.val
        print(f'IK error code: {code}')
        if code == 1:
            print('IK SUCCESS: target is reachable')
            js = result.solution.joint_state
            for name, pos in zip(js.name, js.position):
                if name.startswith('panda_joint'):
                    print(f'{name}: {pos:.4f}')
        else:
            print('IK FAILED: target/orientation may be unreachable')

def main():
    rclpy.init()
    node = IKTest()
    try:
        node.run_test()
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
