import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetCartesianPath
from moveit_msgs.msg import RobotState
from geometry_msgs.msg import Pose


JOINT_NAMES = [
    'panda_joint1', 'panda_joint2', 'panda_joint3',
    'panda_joint4', 'panda_joint5', 'panda_joint6',
    'panda_joint7',
    'panda_finger_joint1', 'panda_finger_joint2',
]

CURRENT = [
    8.472554543392465e-14,
    -0.5788866399322211,
    4.445370108514599e-13,
    -1.7638999999866734,
    -1.3201070483459201e-12,
    2.410500000022366,
    0.7850000000029546,
    0.040000000000000376,
    0.03999709343962303,
]

QUATERNION = (0.5835, 0.5837, 0.3993, -0.3992)


class CartesianPathTest(Node):
    def __init__(self):
        super().__init__('three_stage_cartesian_test')
        self.client = self.create_client(
            GetCartesianPath, '/compute_cartesian_path'
        )

    def run(self):
        if not self.client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error(
                '/compute_cartesian_path unavailable'
            )
            return

        request = GetCartesianPath.Request()

        request.header.frame_id = 'world'

        request.start_state = RobotState()
        request.start_state.joint_state.name = JOINT_NAMES
        request.start_state.joint_state.position = CURRENT
        request.start_state.is_diff = False

        request.group_name = 'panda_arm'
        request.link_name = 'panda_hand'

        targets = [
            (0.550, -0.500, 0.911),
            (0.550, -0.500, 0.961),
            (0.550, -0.450, 0.961),
        ]

        for x, y, z in targets:
            pose = Pose()
            pose.position.x = x
            pose.position.y = y
            pose.position.z = z

            pose.orientation.x = QUATERNION[0]
            pose.orientation.y = QUATERNION[1]
            pose.orientation.z = QUATERNION[2]
            pose.orientation.w = QUATERNION[3]

            request.waypoints.append(pose)

        request.max_step = 0.01
        request.jump_threshold = 0.0
        request.avoid_collisions = True
        request.max_velocity_scaling_factor = 0.1
        request.max_acceleration_scaling_factor = 0.1

        self.get_logger().info(
            'Computing Cartesian path ONLY. No execution.'
        )

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(
            self, future, timeout_sec=60.0
        )

        if not future.done() or future.result() is None:
            self.get_logger().error(
                'Cartesian path service timeout or no response'
            )
            return

        response = future.result()

        self.get_logger().info(
            f'Error code: {response.error_code.val}'
        )
        self.get_logger().info(
            f'Cartesian fraction: {response.fraction:.4f}'
        )
        self.get_logger().info(
            f'Trajectory points: '
            f'{len(response.solution.joint_trajectory.points)}'
        )

        if response.solution.joint_trajectory.points:
            self.get_logger().info(
                'Trajectory joint names: '
                + ', '.join(
                    response.solution.joint_trajectory.joint_names
                )
            )

        if response.error_code.val == 1 and response.fraction >= 0.999:
            self.get_logger().info(
                'CARTESIAN PLAN SUCCESS - NOT EXECUTED'
            )
        else:
            self.get_logger().error(
                'CARTESIAN PLAN INCOMPLETE - NOT EXECUTED'
            )


def main():
    rclpy.init()
    node = CartesianPathTest()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
