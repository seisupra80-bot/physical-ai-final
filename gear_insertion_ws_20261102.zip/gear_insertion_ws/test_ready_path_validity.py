import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState


class PathValidityTest(Node):
    def __init__(self):
        super().__init__('ready_path_validity_test')
        self.client = self.create_client(
            GetStateValidity, '/check_state_validity'
        )

    def check(self, positions):
        request = GetStateValidity.Request()
        request.robot_state = RobotState()
        request.robot_state.joint_state.name = [
            'panda_joint1', 'panda_joint2', 'panda_joint3',
            'panda_joint4', 'panda_joint5', 'panda_joint6',
            'panda_joint7',
        ]
        request.robot_state.joint_state.position = positions
        request.group_name = 'panda_arm'

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)

        if not future.done() or future.result() is None:
            return None, []

        response = future.result()
        contacts = [
            f'{c.contact_body_1} <-> {c.contact_body_2}'
            for c in response.contacts
        ]
        return response.valid, contacts


def main():
    rclpy.init()
    node = PathValidityTest()

    try:
        node.get_logger().info('Waiting for /check_state_validity...')
        if not node.client.wait_for_service(timeout_sec=10.0):
            node.get_logger().error('Service unavailable.')
            return

        start = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        ready = [0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785]

        for i in range(31):
            t = i / 100.0 if i <= 20 else 0.2 + (i - 20) * 0.01
            positions = [
                a + t * (b - a) for a, b in zip(start, ready)
            ]
            valid, contacts = node.check(positions)

            if valid is None:
                node.get_logger().error(f't={t:.2f}: NO RESPONSE')
                continue

            status = 'VALID' if valid else 'INVALID'
            node.get_logger().info(f't={t:.2f}: {status}')

            if not valid and contacts:
                node.get_logger().info(
                    '  Contacts: ' + ', '.join(contacts[:4])
                )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
