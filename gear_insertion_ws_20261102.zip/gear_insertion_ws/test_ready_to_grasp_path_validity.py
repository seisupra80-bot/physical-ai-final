import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState


JOINT_NAMES = [
    'panda_joint1', 'panda_joint2', 'panda_joint3',
    'panda_joint4', 'panda_joint5', 'panda_joint6',
    'panda_joint7',
    'panda_finger_joint1', 'panda_finger_joint2',
]

READY = [
    0.0, -0.7204676, 0.0, -1.8860, 0.0, 2.5307748, 0.785,
    0.04, 0.04,
]

GRASP = [
    0.0, -0.5534, 0.0, -1.7639, 0.0, 2.4105, 0.785,
    0.04, 0.04,
]


class ReadyToGraspPathValidity(Node):
    def __init__(self):
        super().__init__('ready_to_grasp_path_validity')
        self.client = self.create_client(
            GetStateValidity, '/check_state_validity'
        )

    def check(self, positions):
        request = GetStateValidity.Request()
        request.robot_state = RobotState()
        request.robot_state.joint_state.name = JOINT_NAMES
        request.robot_state.joint_state.position = positions
        request.robot_state.is_diff = False
        request.group_name = 'panda_arm'

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(
            self, future, timeout_sec=5.0
        )

        if not future.done() or future.result() is None:
            return None, []

        response = future.result()
        contacts = [
            f'{c.contact_body_1} <-> {c.contact_body_2}'
            for c in response.contacts
        ]
        return response.valid, contacts


def main():
    rclpy.init()
    node = ReadyToGraspPathValidity()

    try:
        node.get_logger().info(
            'Checking path: READY -> GRASP candidate'
        )

        if not node.client.wait_for_service(timeout_sec=10.0):
            node.get_logger().error(
                '/check_state_validity unavailable'
            )
            return

        invalid_count = 0
        error_count = 0
        steps = 30

        for i in range(steps + 1):
            t = i / steps
            positions = [
                a + t * (b - a)
                for a, b in zip(READY, GRASP)
            ]

            valid, contacts = node.check(positions)

            if valid is None:
                error_count += 1
                node.get_logger().error(
                    f'{i}/{steps} t={t:.3f}: NO RESPONSE'
                )
                continue

            if valid:
                node.get_logger().info(
                    f'{i}/{steps} t={t:.3f}: VALID'
                )
            else:
                invalid_count += 1
                node.get_logger().error(
                    f'{i}/{steps} t={t:.3f}: INVALID'
                )
                for contact in contacts[:5]:
                    node.get_logger().error(
                        f'  Contact: {contact}'
                    )

        node.get_logger().info(
            f'Path check finished: '
            f'INVALID={invalid_count}, NO_RESPONSE={error_count}, '
            f'TOTAL={steps + 1}'
        )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
