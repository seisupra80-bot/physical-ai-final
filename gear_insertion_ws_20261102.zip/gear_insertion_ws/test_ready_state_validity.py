#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState


class StateValidityTest(Node):

    def __init__(self):
        super().__init__('state_validity_test')

        self.latest_joint_state = None

        self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10,
        )

        self.client = self.create_client(
            GetStateValidity,
            '/check_state_validity',
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg


def main():

    rclpy.init()
    node = StateValidityTest()

    try:

        node.get_logger().info(
            'Waiting for /joint_states...'
        )

        for _ in range(50):
            rclpy.spin_once(node, timeout_sec=0.1)

            if node.latest_joint_state is not None:
                break

        if node.latest_joint_state is None:
            node.get_logger().error(
                'No joint state received. Aborting.'
            )
            return

        node.get_logger().info(
            'Waiting for /check_state_validity...'
        )

        if not node.client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error(
                '/check_state_validity is unavailable. Aborting.'
            )
            return

        joint_state = node.latest_joint_state

        robot_state = RobotState()

        robot_state.joint_state.name = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7',
        ]

        robot_state.joint_state.position = [
            0.0,
            -0.785,
            0.0,
            -2.356,
            0.0,
            1.571,
            0.785,
        ]

        request = GetStateValidity.Request()
        request.robot_state = robot_state
        request.group_name = 'panda_arm'

        node.get_logger().info(
            'Checking READY CANDIDATE posture only.'
        )

        future = node.client.call_async(request)

        while rclpy.ok() and not future.done():
            rclpy.spin_once(node, timeout_sec=0.1)

        if not future.done():
            node.get_logger().error(
                'State validity request did not complete.'
            )
            return

        response = future.result()

        if response is None:
            node.get_logger().error(
                'No response from MoveIt.'
            )
            return

        node.get_logger().info(
            f'is_valid = {response.valid}'
        )

        if response.valid:
            node.get_logger().info(
                'READY CANDIDATE: VALID'
            )
        else:
            node.get_logger().error(
                'READY CANDIDATE: INVALID'
            )

            if response.contacts:
                node.get_logger().error(
                    f'Collision contacts: {len(response.contacts)}'
                )

                for contact in response.contacts:
                    node.get_logger().error(
                        f'  {contact.contact_body_1} <-> '
                        f'{contact.contact_body_2}'
                    )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
