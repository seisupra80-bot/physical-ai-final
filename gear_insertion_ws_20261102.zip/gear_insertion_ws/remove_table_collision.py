import rclpy
from rclpy.node import Node
from moveit_msgs.srv import ApplyPlanningScene
from moveit_msgs.msg import PlanningScene, CollisionObject

class RemoveTable(Node):
    def __init__(self):
        super().__init__('remove_table_collision')
        self.client = self.create_client(
            ApplyPlanningScene, '/apply_planning_scene')

    def run(self):
        if not self.client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error('Service unavailable')
            return

        scene = PlanningScene()
        scene.is_diff = True

        obj = CollisionObject()
        obj.id = 'gear_table'
        obj.operation = CollisionObject.REMOVE
        scene.world.collision_objects.append(obj)

        req = ApplyPlanningScene.Request()
        req.scene = scene
        future = self.client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=10.0)

        if future.done() and future.result() and future.result().success:
            self.get_logger().info('TABLE COLLISION REMOVED')
        else:
            self.get_logger().error('Removal failed')

def main():
    rclpy.init()
    node = RemoveTable()
    node.run()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
