#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import MotionPlanRequest, Constraints, JointConstraint


class ReadyToReadyTest(Node):

    def __init__(self):
        super().__init__('ready_to_ready_test')

        self.latest_joint_state = None

        self.sub = self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10
        )

        self.client = self.create_client(
            GetMotionPlan,
            '/plan_kinematic_path'
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg

    def run(self):

        self.get_logger().info(
            'Waiting for /joint_states...'
        )

        while rclpy.ok() and self.latest_joint_state is None:
            rclpy.spin_once(self, timeout_sec=0.1)

        self.get_logger().info(
            'Joint state received.'
        )

        self.get_logger().info(
            'Waiting for /plan_kinematic_path...'
        )

        if not self.client.wait_for_service(timeout_sec=5.0):
            self.get_logger().error(
                '/plan_kinematic_path is unavailable.'
            )
            return

        # READY posture
        joint_names = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7',
        ]

        ready_positions = [
            0.0,
            -0.785,
            0.0,
            -2.356,
            0.0,
            1.571,
            0.785,
        ]

        request = GetMotionPlan.Request()

        plan = MotionPlanRequest()

        plan.group_name = 'panda_arm'
        plan.pipeline_id = 'ompl'
        plan.planner_id = 'RRTConnect'

        plan.num_planning_attempts = 1
        plan.allowed_planning_time = 2.0

        plan.max_velocity_scaling_factor = 0.1
        plan.max_acceleration_scaling_factor = 0.1

        # -------------------------------------------------
        # Start = READY posture
        # -------------------------------------------------

        plan.start_state.joint_state.name = joint_names
        plan.start_state.joint_state.position = ready_positions
        plan.start_state.is_diff = False

        # -------------------------------------------------
        # Goal = READY posture
        # -------------------------------------------------

        goal_constraints = Constraints()

        for name, position in zip(
            joint_names,
            ready_positions
        ):
            jc = JointConstraint()

            jc.joint_name = name
            jc.position = position
            jc.tolerance_above = 0.01
            jc.tolerance_below = 0.01
            jc.weight = 1.0

            goal_constraints.joint_constraints.append(jc)

        plan.goal_constraints.append(goal_constraints)

        request.motion_plan_request = plan

        self.get_logger().info(
            '=========================================='
        )
        self.get_logger().info(
            'READY -> READY PLAN TEST'
        )
        self.get_logger().info(
            'Start: READY posture'
        )
        self.get_logger().info(
            'Goal : READY posture'
        )
        self.get_logger().info(
            'NO TRAJECTORY EXECUTION'
        )
        self.get_logger().info(
            '=========================================='
        )

        future = self.client.call_async(request)

        while rclpy.ok() and not future.done():
            rclpy.spin_once(self, timeout_sec=0.1)

        if not future.done():
            self.get_logger().error(
                'Planning request did not finish.'
            )
            return

        response = future.result()

        if response is None:
            self.get_logger().error(
                'No response from MoveIt.'
            )
            return

        error_code = response.motion_plan_response.error_code.val

        planning_time = (
            response.motion_plan_response.planning_time
        )

        trajectory = (
            response.motion_plan_response.trajectory
        )

        point_count = len(
            trajectory.joint_trajectory.points
        )

        self.get_logger().info(
            f'MoveIt error code: {error_code}'
        )

        self.get_logger().info(
            f'Planning time: {planning_time:.3f} seconds'
        )

        self.get_logger().info(
            f'Trajectory points: {point_count}'
        )

        if error_code == 1:
            self.get_logger().info(
                '=========================================='
            )
            self.get_logger().info(
                'READY -> READY PLAN: SUCCESS'
            )
            self.get_logger().info(
                'NO TRAJECTORY WAS EXECUTED.'
            )
            self.get_logger().info(
                '=========================================='
            )
        else:
            self.get_logger().error(
                '=========================================='
            )
            self.get_logger().error(
                'READY -> READY PLAN: FAILED'
            )
            self.get_logger().error(
                'NO TRAJECTORY WAS EXECUTED.'
            )
            self.get_logger().error(
                '=========================================='
            )


def main(args=None):

    rclpy.init(args=args)

    node = ReadyToReadyTest()

    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
