import rclpy
from rclpy.node import Node
from moveit_msgs.srv import GetStateValidity
from moveit_msgs.msg import RobotState


class ZeroStateTest(Node):
    def __init__(self):
        super().__init__('zero_state_validity_test')
        self.client = self.create_client(
            GetStateValidity, '/check_state_validity'
        )


def main():
    rclpy.init()
    node = ZeroStateTest()

    try:
        node.get_logger().info('Waiting for /check_state_validity...')
        if not node.client.wait_for_service(timeout_sec=10.0):
            node.get_logger().error('Service unavailable. Aborting.')
            return

        state = RobotState()
        state.joint_state.name = [
            'panda_joint1', 'panda_joint2', 'panda_joint3',
            'panda_joint4', 'panda_joint5', 'panda_joint6',
            'panda_joint7',
        ]
        state.joint_state.position = [0.0] * 7

        request = GetStateValidity.Request()
        request.robot_state = state
        request.group_name = 'panda_arm'

        node.get_logger().info('Checking ZERO posture only.')
        future = node.client.call_async(request)

        while rclpy.ok() and not future.done():
            rclpy.spin_once(node, timeout_sec=0.1)

        response = future.result()
        if response is None:
            node.get_logger().error('No response from MoveIt.')
            return

        node.get_logger().info(f'is_valid = {response.valid}')
        node.get_logger().info(
            f'Collision contacts: {len(response.contacts)}'
        )

        for i, contact in enumerate(response.contacts, start=1):
            node.get_logger().info(
                f'--- Contact {i} ---'
            )
            node.get_logger().info(
                f'Bodies: {contact.contact_body_1} <-> '
                f'{contact.contact_body_2}'
            )
            node.get_logger().info(
                f'Frame: {contact.header.frame_id}'
            )
            node.get_logger().info(
                f'Position: x={contact.position.x:.6f}, '
                f'y={contact.position.y:.6f}, '
                f'z={contact.position.z:.6f} m'
            )
            node.get_logger().info(
                f'Normal: x={contact.normal.x:.6f}, '
                f'y={contact.normal.y:.6f}, '
                f'z={contact.normal.z:.6f}'
            )
            node.get_logger().info(
                f'Depth: {contact.depth:.6f} m'
            )

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
