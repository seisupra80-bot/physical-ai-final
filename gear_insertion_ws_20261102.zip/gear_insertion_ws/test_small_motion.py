import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from builtin_interfaces.msg import Duration


JOINT_NAMES = [
    'panda_joint1',
    'panda_joint2',
    'panda_joint3',
    'panda_joint4',
    'panda_joint5',
    'panda_joint6',
    'panda_joint7',
]


class SmallMotionTest(Node):

    def __init__(self):
        super().__init__('small_motion_test')
        self.client = ActionClient(
            self,
            FollowJointTrajectory,
            '/panda_arm_controller/follow_joint_trajectory',
        )


def main():
    rclpy.init()
    node = SmallMotionTest()

    try:
        node.get_logger().info('Waiting for action server...')

        if not node.client.wait_for_server(timeout_sec=5.0):
            node.get_logger().error('Server unavailable. Aborting.')
            return

        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = JOINT_NAMES

        point = JointTrajectoryPoint()
        point.positions = [
            0.0, -0.05, 0.0, 0.0, 0.0, 0.0, 0.0
        ]
        point.velocities = [0.0] * 7
        point.time_from_start = Duration(sec=3, nanosec=0)
        goal.trajectory.points = [point]

        node.get_logger().warn(
            'Sending small direct trajectory: Joint 2 to -0.05 rad.'
        )

        send_future = node.client.send_goal_async(goal)
        rclpy.spin_until_future_complete(node, send_future)

        goal_handle = send_future.result()

        if goal_handle is None or not goal_handle.accepted:
            node.get_logger().error('Trajectory goal rejected.')
            return

        node.get_logger().info('Goal accepted. Waiting for completion...')

        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(node, result_future)

        result = result_future.result()

        if result is not None:
            node.get_logger().info(
                f'Trajectory result error_code: '
                f'{result.result.error_code}'
            )
            node.get_logger().info(result.result.error_string)

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
