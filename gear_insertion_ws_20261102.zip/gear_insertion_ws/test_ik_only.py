import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetPositionIK


class IKOnlyTest(Node):

    def __init__(self):
        super().__init__('ik_only_test')

        self.latest_joint_state = None

        self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10,
        )

        self.client = self.create_client(
            GetPositionIK,
            '/compute_ik',
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg


def main():
    rclpy.init()
    node = IKOnlyTest()

    try:
        node.get_logger().info('Waiting for /joint_states...')

        for _ in range(50):
            rclpy.spin_once(node, timeout_sec=0.1)
            if node.latest_joint_state is not None:
                break

        if node.latest_joint_state is None:
            node.get_logger().error('No joint state received.')
            return

        node.get_logger().info('Waiting for /compute_ik...')

        if not node.client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error('/compute_ik is unavailable.')
            return

        request = GetPositionIK.Request()
        ik = request.ik_request

        ik.group_name = 'panda_arm'
        ik.robot_state.joint_state = node.latest_joint_state
        ik.robot_state.is_diff = False

        # 手先リンクを指定
        ik.ik_link_name = 'panda_hand'

        # 初回はハンドルの中ほどを目標にする
        # 座標系は world
        ik.pose_stamped.header.frame_id = 'world'
        ik.pose_stamped.pose.position.x = 0.550
        ik.pose_stamped.pose.position.y = -0.380
        ik.pose_stamped.pose.position.z = 0.830

        # 手先の向きは現在の姿勢を仮置きせず、
        # まず下向きに近い姿勢を試す
        ik.pose_stamped.pose.orientation.x = 1.0
        ik.pose_stamped.pose.orientation.y = 0.0
        ik.pose_stamped.pose.orientation.z = 0.0
        ik.pose_stamped.pose.orientation.w = 0.0

        ik.avoid_collisions = True
        ik.timeout.sec = 2

        node.get_logger().info('===================================')
        node.get_logger().info('IK ONLY TEST')
        node.get_logger().info('Target frame: world')
        node.get_logger().info('Target position: (0.550, -0.380, 0.830)')
        node.get_logger().info('NO ROBOT MOTION')
        node.get_logger().info('===================================')

        future = node.client.call_async(request)

        while rclpy.ok() and not future.done():
            rclpy.spin_once(node, timeout_sec=0.1)

        response = future.result()

        if response is None:
            node.get_logger().error('No IK response.')
            return

        node.get_logger().info(
            f'IK error code: {response.error_code.val}'
        )

        if response.error_code.val == 1:
            solution = response.solution.joint_state
            node.get_logger().info('IK SUCCESS')
            for name, position in zip(
                solution.name, solution.position
            ):
                if name.startswith('panda_joint'):
                    node.get_logger().info(
                        f'{name}: {position:.4f} rad'
                    )
        else:
            node.get_logger().error('IK FAILED; no motion was executed.')

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
