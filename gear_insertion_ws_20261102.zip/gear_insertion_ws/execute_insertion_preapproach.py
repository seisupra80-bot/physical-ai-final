import rclpy
from rclpy.node import Node

from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import MotionPlanRequest
from moveit_msgs.msg import Constraints
from moveit_msgs.msg import PositionConstraint
from shape_msgs.msg import SolidPrimitive

from control_msgs.action import FollowJointTrajectory
from rclpy.action import ActionClient


class ExecuteInsertionPreApproach(Node):

    def __init__(self):
        super().__init__('execute_insertion_preapproach')

        self.latest_joint_state = None

        self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10
        )

        self.plan_client = self.create_client(
            GetMotionPlan,
            '/plan_kinematic_path'
        )

        self.action_client = ActionClient(
            self,
            FollowJointTrajectory,
            '/panda_arm_controller/follow_joint_trajectory'
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg

    def make_pose(self, x, y, z):
        from geometry_msgs.msg import Pose

        pose = Pose()
        pose.position.x = x
        pose.position.y = y
        pose.position.z = z
        pose.orientation.w = 1.0

        return pose

    def make_plan_request(self):

        joints = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7'
        ]

        current = {}

        for name, position in zip(
            self.latest_joint_state.name,
            self.latest_joint_state.position
        ):
            if name in joints:
                current[name] = position

        req = GetMotionPlan.Request()
        mpr = MotionPlanRequest()

        mpr.group_name = 'panda_arm'
        mpr.num_planning_attempts = 10
        mpr.allowed_planning_time = 5.0
        mpr.max_velocity_scaling_factor = 0.2
        mpr.max_acceleration_scaling_factor = 0.2

        mpr.start_state.joint_state.name = joints
        mpr.start_state.joint_state.position = [
            current[j] for j in joints
        ]

        pc = PositionConstraint()
        pc.header.frame_id = 'world'
        pc.link_name = 'panda_link8'

        primitive = SolidPrimitive()
        primitive.type = SolidPrimitive.SPHERE
        primitive.dimensions = [0.08]

        pc.constraint_region.primitives.append(primitive)

        pc.constraint_region.primitive_poses.append(
            self.make_pose(
                0.50,
                -0.25,
                0.80
            )
        )

        pc.weight = 1.0

        constraints = Constraints()
        constraints.position_constraints.append(pc)

        mpr.goal_constraints.append(constraints)

        req.motion_plan_request = mpr

        return req

    def run(self):

        self.get_logger().info('Waiting for /joint_states...')

        while rclpy.ok() and self.latest_joint_state is None:
            rclpy.spin_once(self, timeout_sec=0.1)

        self.get_logger().info('Waiting for MoveIt planning service...')

        while rclpy.ok() and not self.plan_client.wait_for_service(
            timeout_sec=1.0
        ):
            pass

        self.get_logger().info(
            'Planning insertion pre-approach...'
        )

        future = self.plan_client.call_async(
            self.make_plan_request()
        )

        while rclpy.ok() and not future.done():
            rclpy.spin_once(self, timeout_sec=0.1)

        response = future.result()

        if response is None:
            self.get_logger().error(
                'Planning failed: no response'
            )
            return

        plan = response.motion_plan_response

        if len(plan.trajectory.joint_trajectory.points) == 0:
            self.get_logger().error(
                'Planning failed: no trajectory'
            )
            return

        self.get_logger().info(
            'Planning SUCCESS'
        )

        trajectory = plan.trajectory.joint_trajectory

        # --------------------------------------------------
        # Make execution trajectory
        # --------------------------------------------------

        trajectory.header.stamp.sec = 0
        trajectory.header.stamp.nanosec = 0

        self.get_logger().info(
            f'Executing {len(trajectory.points)} trajectory points...'
        )

        self.get_logger().info(
            'Waiting for panda_arm_controller...'
        )

        if not self.action_client.wait_for_server(
            timeout_sec=10.0
        ):
            self.get_logger().error(
                'FollowJointTrajectory action server not available'
            )
            return

        goal = FollowJointTrajectory.Goal()
        goal.trajectory = trajectory

        send_future = self.action_client.send_goal_async(goal)

        while rclpy.ok() and not send_future.done():
            rclpy.spin_once(self, timeout_sec=0.1)

        goal_handle = send_future.result()

        if not goal_handle.accepted:
            self.get_logger().error(
                'Trajectory goal rejected'
            )
            return

        self.get_logger().info(
            'Trajectory goal accepted'
        )

        result_future = goal_handle.get_result_async()

        while rclpy.ok() and not result_future.done():
            rclpy.spin_once(self, timeout_sec=0.1)

        result = result_future.result().result

        self.get_logger().info(
            f'error_code: {result.error_code}'
        )

        self.get_logger().info(
            f'error_string: {result.error_string}'
        )


def main():

    rclpy.init()

    node = ExecuteInsertionPreApproach()

    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
