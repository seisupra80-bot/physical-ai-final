import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from moveit_msgs.srv import GetMotionPlan
from moveit_msgs.msg import (
    MotionPlanRequest,
    Constraints,
    PositionConstraint,
    OrientationConstraint,
)
from geometry_msgs.msg import PoseStamped
from shape_msgs.msg import SolidPrimitive


class HandlePlanTest(Node):

    def __init__(self):
        super().__init__('handle_plan_test')

        self.latest_joint_state = None

        self.create_subscription(
            JointState,
            '/merged_joint_states',
            self.joint_state_callback,
            10
        )

        self.client = self.create_client(
            GetMotionPlan,
            '/plan_kinematic_path'
        )

    def joint_state_callback(self, msg):
        self.latest_joint_state = msg


def main():

    rclpy.init()
    node = HandlePlanTest()

    try:
        node.get_logger().info(
            'Waiting for merged joint states...'
        )

        for _ in range(50):
            rclpy.spin_once(node, timeout_sec=0.1)

            if node.latest_joint_state is not None:
                break

        if node.latest_joint_state is None:
            node.get_logger().error('No joint states. Aborting.')
            return

        joint_state = node.latest_joint_state
        state_map = dict(zip(joint_state.name, joint_state.position))

        arm_names = [
            'panda_joint1',
            'panda_joint2',
            'panda_joint3',
            'panda_joint4',
            'panda_joint5',
            'panda_joint6',
            'panda_joint7',
        ]

        if not all(name in state_map for name in arm_names):
            node.get_logger().error('Missing arm joints. Aborting.')
            return

        node.get_logger().info('Current arm state received.')

        if not node.client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error('Planning service unavailable.')
            return

        request = GetMotionPlan.Request()
        plan = MotionPlanRequest()

        plan.group_name = 'panda_arm'
        plan.pipeline_id = 'ompl'
        plan.planner_id = 'RRTConnect'
        plan.num_planning_attempts = 3
        plan.allowed_planning_time = 5.0
        plan.max_velocity_scaling_factor = 0.05
        plan.max_acceleration_scaling_factor = 0.05

        # Use the known collision-free READY posture for planning only.
        plan.start_state.joint_state.name = arm_names
        plan.start_state.joint_state.position = [
            0.0,
            -0.785,
            0.0,
            -2.356,
            0.0,
            1.571,
            0.785,
        ]
        plan.start_state.is_diff = False

        # Handle approach target in world coordinates.
        # World: x=0.55, y=-0.378, z=1.05
        # This is above the handle top, not a grasp command.
        target = PoseStamped()
        target.header.frame_id = 'world'
        target.pose.position.x = 0.55
        target.pose.position.y = -0.378
        target.pose.position.z = 1.05
        target.pose.orientation.w = 1.0

        # Initial orientation: retain current hand orientation.
        # The target orientation is deliberately not constrained yet.

        constraints = Constraints()

        position = PositionConstraint()
        position.header.frame_id = 'world'
        position.link_name = 'panda_hand'
        position.weight = 1.0
        position.constraint_region.primitives.append(
            SolidPrimitive(
                type=SolidPrimitive.BOX,
                dimensions=[0.06, 0.06, 0.06]
            )
        )
        position.constraint_region.primitive_poses.append(
            target.pose
        )
        constraints.position_constraints.append(position)

        plan.goal_constraints.append(constraints)
        request.motion_plan_request = plan

        node.get_logger().info(
            'PLAN ONLY: target above insertion gear handle'
        )
        node.get_logger().info(
            'Target world position: (0.55, -0.378, 1.05)'
        )
        node.get_logger().info('NO TRAJECTORY EXECUTION')

        future = node.client.call_async(request)

        while rclpy.ok() and not future.done():
            rclpy.spin_once(node, timeout_sec=0.1)

        response = future.result()

        if response is None:
            node.get_logger().error('No planning response.')
            return

        result = response.motion_plan_response

        node.get_logger().info(
            f'MoveIt error code: {result.error_code.val}'
        )
        node.get_logger().info(
            f'Planning time: {result.planning_time:.3f} seconds'
        )
        points = result.trajectory.joint_trajectory.points

        node.get_logger().info(
            f'Trajectory points: {len(points)}'
        )

        if points:
            trajectory = result.trajectory.joint_trajectory
            joint_names = trajectory.joint_names

            sample_indices = sorted(set([
                0,
                len(points) // 2,
                len(points) - 1
            ]))

            for index in sample_indices:
                point = points[index]
                node.get_logger().info(
                    f'Trajectory point {index + 1}/{len(points)} '
                    f'(time={point.time_from_start.sec + point.time_from_start.nanosec * 1e-9:.3f}s)'
                )

                for name, value in zip(joint_names, point.positions):
                    node.get_logger().info(
                        f'  {name}: {value:.4f} rad'
                    )

        if result.error_code.val == 1:
            node.get_logger().info('PLAN ONLY: SUCCESS')
            node.get_logger().info('Nothing was executed.')
        else:
            node.get_logger().error('PLAN ONLY: FAILED')
            node.get_logger().error('Nothing was executed.')

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
