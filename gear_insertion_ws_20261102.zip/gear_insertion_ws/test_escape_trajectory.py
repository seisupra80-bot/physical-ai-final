from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

JOINT_NAMES = [
    'panda_joint1',
    'panda_joint2',
    'panda_joint3',
    'panda_joint4',
    'panda_joint5',
    'panda_joint6',
    'panda_joint7',
]

START = [
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
]

GOAL_A = [
    0.0, -0.3, 0.0, -2.2, 0.0, 1.5, 0.785
]

trajectory = JointTrajectory()
trajectory.joint_names = JOINT_NAMES

for i in range(6):

    t = 0.05 * i

    positions = [
        s + (g - s) * t
        for s, g in zip(START, GOAL_A)
    ]

    point = JointTrajectoryPoint()
    point.positions = positions
    point.time_from_start.sec = i + 1

    trajectory.points.append(point)

print('========================================')
print('ESCAPE TRAJECTORY')
print('NO MOTION COMMAND WAS SENT')
print('========================================')

for i, point in enumerate(trajectory.points):

    print(
        f'point {i}: '
        f't={0.05 * i:.2f}, '
        f'positions={point.positions}, '
        f'time={point.time_from_start.sec}s'
    )

print('========================================')
